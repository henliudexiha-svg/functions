# 剧情调度。
# jq 是已完成剧情节点，jqa 是目标剧情节点；tag=jq 表示需要播放剧情。
# tag=jqa 表示当前剧情已经结束，需要把 jq 同步到 jqa 并恢复玩家控制。
execute as @a[tag=jqa] run tag @s remove jq
execute as @a[tag=jqa] run scoreboard players operation @s jq = @s jqa
# 部分剧情结束后会自动跳到下一个中间节点，并再次打 jq 标签继续播放。
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=9}] jqa 10
execute as @a[tag=jqa] run tag @s[scores={jq=9}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=10}] jqa 11
execute as @a[tag=jqa] run tag @s[scores={jq=10}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=16}] jqa 17
execute as @a[tag=jqa] run tag @s[scores={jq=16}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=20}] jqa 21
execute as @a[tag=jqa] run tag @s[scores={jq=20}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=22}] jqa 23
execute as @a[tag=jqa] run tag @s[scores={jq=22}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=29}] jqa 30
execute as @a[tag=jqa] run tag @s[scores={jq=29}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=30}] jqa 31
execute as @a[tag=jqa] run tag @s[scores={jq=30}] add jq
execute as @a[tag=jqa] run scoreboard players set @s[scores={jq=57}] jqa 58
execute as @a[tag=jqa] run tag @s[scores={jq=57}] add jq

execute as @a[tag=jqa] run camera @s clear 
execute as @a[tag=jqa] run inputpermission set @s movement enabled
execute as @a[tag=jqa] run hud @s reset all
execute as @a[tag=jqa] run scoreboard players set @s jqtime 0
execute as @a[tag=jqa] run tag @s remove jqa

# 根据目标节点 jqa 调用具体剧情函数；只有 jq != jqa 时才继续播放。
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 1 at @s run function jq/1/jq1
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 2 at @s run function jq/1/jq2
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 3 at @s run function jq/1/jq3
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 4 at @s run function jq/1/jq4
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 5 at @s run function jq/1/jq5
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 6 at @s run function jq/1/jq6
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 7 at @s run function jq/1/jq7
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 8 at @s run function jq/1/jq8
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 9 at @s run function jq/1/jq9
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 10 at @s run function jq/1/jq10
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 11 at @s run function jq/1/jq11
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 12 at @s run function jq/1/jq12
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 13 at @s run function jq/1/jq13
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 14 at @s run function jq/1/jq14
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 15 at @s run function jq/1/jq15
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 16 at @s run function jq/1/jq16
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 17 at @s run function jq/1/jq17
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 18 at @s run function jq/1/jq18
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 19 at @s run function jq/1/jq19
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 20 at @s run function jq/1/jq20
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 21 at @s run function jq/1/jq21
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 22 at @s run function jq/1/jq22
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 23 at @s run function jq/1/jq23
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 24 at @s run function jq/1/jq24
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 25 at @s run function jq/1/jq25
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 26 at @s run function jq/1/jq26
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 27 at @s run function jq/1/jq27
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 28 at @s run function jq/1/jq28
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 29 at @s run function jq/1/jq29
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 30 at @s run function jq/1/jq30
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 31 at @s run function jq/1/jq31
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 32 at @s run function jq/1/jq32
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 50 at @s run function jq/2/jq50
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 51 at @s run function jq/2/jq51
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 52 at @s run function jq/2/jq52
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 53 at @s run function jq/2/jq53
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 54 at @s run function jq/2/jq54zx
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 55 at @s run function jq/2/jq55
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 56 at @s run function jq/2/jq56
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 57 at @s run function jq/2/jq57
execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 58 at @s run function jq/2/jq58
# execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 59 at @s run function jq/2/jq59
# execute as @a[tag=jq] unless score @s jq = @s jqa if score @s jqa matches 60 at @s run function jq/2/jq60

















execute as @a[tag=jq] unless score @s jq = @s jqa run scoreboard players add @s jqtime 1 
