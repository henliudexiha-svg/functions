tag @p add jq
scoreboard players add @p jqa 1