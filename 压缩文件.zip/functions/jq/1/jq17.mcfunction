execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 1 run clear @s minecraft:amethyst_cluster
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"还真：充能完毕，是否将当前场景虚拟化，回归最初锚点。"}]}
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"【本次模拟结束】(下一世不会清除物品，请放心的肝吧)"}]}
execute as @s if score @s jqtime matches 7 run tellraw @s {"rawtext":[{"text":"【你可以在以下选项中选择一项进行保留：】"}]}
execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"1.本次模拟中自身持有的一件物品。"}]}
execute as @s if score @s jqtime matches 9 run tellraw @s {"rawtext":[{"text":"2.本次模拟中自身的修行境界。"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"3.本次模拟中与自身关系密切的一位人员的模拟记忆。此记忆可让该人员继承。。"}]}
execute as @s if score @s jqtime matches 11 run tellraw @s {"rawtext":[{"text":"4.放弃以上选择，加快充能进度"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这就是筑基大圆满修士么……"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 如果没有仙凡瘴，恐怕就算我轮回百世，计谋百出，也不足以对他们造成威胁。"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这仙凡瘴到底是怎么回事，修仙者不是由凡人一步步成长而来么，怎么凡人的血液会对修仙者有如此可怕的克制作用？"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 伏击道玄子与寇洪一战，基本在我的预料之中。先是用死囚的血液浸泡过的子弹消耗他们的实力，随后用结丹功法一事动其心神，然后用血雨一锤定音，将二人虚弱到极致后生擒……"}]}
execute as @s if score @s jqtime matches 27 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 没想到的是仙凡瘴对修仙者的克制如此厉害，直接导致寇洪身死道消。"}]}
execute as @s if score @s jqtime matches 32 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 更在计划之外的是，原本以为这二人口中的百年兄弟只是随口一说，却没想到两人的关系确实非同寻常。被袭击时，道玄子会出声提醒寇洪，寇洪自知难逃一死，将结丹功法主动送于道玄子。"}]}
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 道玄子见寇洪死于暗算，意难平之下放弃活路，使出了同归于尽的一剑，为寇洪报仇……这一切都说明了二人之间确实有着超乎常人的友谊……"}]}
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 既如此，他们二人怎么会因为一部结丹功法而相互厮杀呢(不解)"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 金丹大道，有我无他……"}]}
execute as @s if score @s jqtime matches 52 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 仙法不能同修么……"}]}
execute as @s if score @s jqtime matches 54 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 亲如兄弟尚且如此，这外面的修仙界又究竟是怎么一副景象？"}]}
execute as @s if score @s jqtime matches 59 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 在这所谓的仙绝之地，想要寻求仙道，还是要在寇洪和道玄子二人身上想办法。上一次我选择了同时袭击他们二人，或许这一次，我可以选择拉拢其中一个。"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 求仙之路，何其难也。"}]}
execute as @s if score @s jqtime matches 66 run camera @s fade time 1 2 7 color 0 0 0 
execute as @s if score @s jqtime matches 68 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 省上没什么东西，我还是选择了加快化虚充能进度选项。"}]}
execute as @s if score @s jqtime matches 68 run tp @s 172 59 260
execute as @s if score @s jqtime matches 76 run tellraw @s {"rawtext":[{"text":"如同设定好的程序一般，一切按部就班的进行着。"}]}
execute as @s if score @s jqtime matches 79 run tellraw @s {"rawtext":[{"text":"科考，中举，当状元。"}]}
execute as @s if score @s jqtime matches 82 run tellraw @s {"rawtext":[{"text":"当县令，开采矿物，造枪。"}]}
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"当杀掉琅琊王，取而代之之后。"}]}
execute as @s if score @s jqtime matches 88 run tellraw @s {"rawtext":[{"text":"你觉得十年时间太长，一日不能掌控天下，就始终要龟缩在江南一地。如果能多给他十年时间调动整个天下的力量，那么将两个修仙者生擒的计划，便多一分胜算。"}]}
execute as @s if score @s jqtime matches 88 run tellraw @s {"rawtext":[{"text":"你决定派心腹潜入宫中，给皇帝暗中下慢性毒药。"}]}
execute as @s at @s if score @s jqtime matches 92 run playsound random.levelup @s
execute as @s if score @s jqtime matches 92 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 92 run scoreboard players set @s rwa 12
execute as @s if score @s jqtime matches 93 run tag @s add jqa 



