execute as @s if score @s jqtime matches 1 run tp @s 115 59 171
execute as @s if score @s jqtime matches 1 run structure load "1/寇洪" 112 64 175
execute as @s if score @s jqtime matches 2 run tellraw @s {"rawtext":[{"text":"-请前往2楼"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-拷打了10多天的寇洪，终于肯说出情报了"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"[寇洪]：我说，我说，我说！"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[寇洪]：凡人之间的瘟疫莫名感染了修仙者，导致瘟疫加强，导致变得能够通过天地灵力传播，最终席卷整个修仙界"}]}
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"[寇洪]: 感染瘟疫的修仙者，轻则修为倒退，重则还道于天。"}]}
execute as @s if score @s jqtime matches 26 run tellraw @s {"rawtext":[{"text":"[寇洪]: 这大瘟疫虽发生在数千年前，现在想想，还是令人不寒而栗。"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 修仙者就任由这瘟疫蔓延吗？"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[寇洪]: 短时间内找不到治愈的方法，他们便从源头下手。修仙者在绝望之下开始对凡人进行大规模屠杀，但没过多久，这种屠杀行为就被强制终止了。"}]}
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"[寇洪]: 因为随着大量凡人死亡，这些凡人体内的瘟疫，不但没有消失，反而像失去束缚一般，全部顺着天地灵气扩散开来，导致了更多修仙者的陨落。"}]}
execute as @s if score @s jqtime matches 43 run tellraw @s {"rawtext":[{"text":"[寇洪]: 无奈之下，修仙者们提出了大迁移计划。"}]}
execute as @s if score @s jqtime matches 47 run tellraw @s {"rawtext":[{"text":"[寇洪]: 将修仙界的全体凡人放逐到周边没有灵气的小世界，再用阵法将其永远隔绝，不让这些凡人返回。"}]}
execute as @s if score @s jqtime matches 52 run tellraw @s {"rawtext":[{"text":"[寇洪]: 后面用了近千年的瘟疫的威胁才被扫除，但是这种瘟疫，一直暗藏与凡人的血脉之中，凡人想要修仙，就必须先清除体内的瘟疫"}]}
execute as @s if score @s jqtime matches 58 run tellraw @s {"rawtext":[{"text":"[寇洪]: 久而久之，这种瘟疫就成了仙凡有别的代名词，于是将其命名为仙凡瘴"}]}
execute as @s if score @s jqtime matches 62 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 原来如此！想来这仙绝之地，根本就不会有修仙者愿意进来"}]}
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 能碰见你们两个，真不知道是幸运还是不幸，哎！"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 明明长生之路就在眼前，但有远在天边，真是白瞎了这回档系统，难道真的只能一世又一世的重复凡人生活？（心里话）"}]}
execute as @s if score @s jqtime matches 74 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不对（心里话）"}]}
execute as @s if score @s jqtime matches 76 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 大迁徙中的凡人，他们是如何来到这仙绝之地的？"}]}
execute as @s if score @s jqtime matches 80 run tellraw @s {"rawtext":[{"text":"[寇洪]: 大瘟疫时代已经过去了数千年，关于当初的种种，我也是道听途说罢了"}]}
execute as @s if score @s jqtime matches 84 run tellraw @s {"rawtext":[{"text":"[寇洪]: 怎么？你还不死心？七十岁的年纪了，还想修仙..."}]}
execute as @s if score @s jqtime matches 87 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 皮又痒了是吧？"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"[寇洪]: 额...若我猜得没错，当年应该是用飞舟之类的法器迁移凡人"}]}
execute as @s if score @s jqtime matches 93 run tellraw @s {"rawtext":[{"text":"[寇洪]: 只可惜后来天地巨变，修仙者都是独来独往，这类法器就很少看到了"}]}
execute as @s if score @s jqtime matches 97 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 天地巨变？是指的那场诡异的大瘟疫吗？"}]}
execute as @s if score @s jqtime matches 100 run tellraw @s {"rawtext":[{"text":"[寇洪]: 事实上，仙凡瘴之所以可以横行，是因为天地间绝大部分修士，在一场大劫中尽数陨落了，修仙界实力大跌，这才无法有效应对仙凡瘴"}]}
execute as @s if score @s jqtime matches 105 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 天地大劫？"}]}
execute as @s if score @s jqtime matches 107 run tellraw @s {"rawtext":[{"text":"[寇洪]: 仙法不可同修，天地巨变后，同一门功法修炼的人越多，效率就越低。"}]}
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 修炼效率降低，便如同大家一起浪费寿元！"}]}
execute as @s if score @s jqtime matches 114 run tellraw @s {"rawtext":[{"text":"[寇洪]: 正是如此！随着越来越多修士寿元将近，无止尽的杀戮便开始了。就算你不愿杀戮，但无法保证对方也这么想"}]}
execute as @s if score @s jqtime matches 119 run tellraw @s {"rawtext":[{"text":"[寇洪]: 所有修仙者，都陷入无尽的猜疑之中"}]}
execute as @s if score @s jqtime matches 122 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 那为何不寻一处隐秘之地，躲起来修炼？"}]}
execute as @s if score @s jqtime matches 125 run tellraw @s {"rawtext":[{"text":"[寇洪]: 修同一功法的人，可感应修行人数以及彼此的位置，这便是大劫的恐怖之处，天地大劫之后，整个修仙界变得无比凋敝"}]}
execute as @s if score @s jqtime matches 130 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 那如今的修仙界是怎样的景象"}]}
execute as @s if score @s jqtime matches 134 run tellraw @s {"rawtext":[{"text":"[寇洪]: 如今的修仙界有两大势力----万仙盟和五老会，万仙们是众多修士组成的松散联盟，凭借灵石或者贡献度兑换修炼功法与资源，五老会是五位顶尖大能，创建的势力，加入后就能获得功法，但需要签下神魂契约，为五老会效命一定的时间。"}]}
execute as @s if score @s jqtime matches 140 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 听你所讲，感觉如今功法也不是那么稀缺的样子？"}]}
execute as @s if score @s jqtime matches 144 run tellraw @s {"rawtext":[{"text":"[寇洪]: 那是因为，通过这种方法获得的，皆为残缺的功法。想要获得更高一层的功法，就要继续为他们卖命"}]}
execute as @s if score @s jqtime matches 149 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这是什么牛马修仙界"}]}
execute as @s if score @s jqtime matches 152 run tellraw @s {"rawtext":[{"text":"[寇洪]: 道玄子到死都不知道，我之所以抢了功法就跑，是因为那本功法并非结丹功法，而是直指元婴真功！！"}]}
execute as @s if score @s jqtime matches 157 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 若是不能离开此地，有这元婴功法也是无用啊！（心里话）"}]}
execute as @s if score @s jqtime matches 160 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 你若能帮我找到前往修仙界的方法，我不仅带你一起回去，这功法也还给你，如何？"}]}
execute as @s if score @s jqtime matches 164 run tellraw @s {"rawtext":[{"text":"[寇洪]: 有一线希望总比困到此地强（心里话）"}]}
execute as @s if score @s jqtime matches 168 run tellraw @s {"rawtext":[{"text":"[寇洪]: 好，我便尽全力帮你"}]}
execute as @s if score @s jqtime matches 170 run camera @s fade time 2 23 2 color 0 0 0
execute as @s if score @s jqtime matches 172 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 172 run kill @e[name=寇洪,x=112,y=64,z=175,r=10]
execute as @s if score @s jqtime matches 175 run tellraw @s {"rawtext":[{"text":"[锚定51年]: 你在寇洪的帮助下，搜集天下史书典籍，力求从上古记载的只言片语中，寻找到关于当初大迁徙时代的线索。"}]}
execute as @s if score @s jqtime matches 180 run tellraw @s {"rawtext":[{"text":"[锚定51年]: 同时，你还动用军队，大肆挖掘古墓，试图从中找到些许蛛丝马迹。虽然引得民怨沸腾、百官日日上书劝诫，但都被你一一强行压下。"}]}
execute as @s if score @s jqtime matches 185 run tellraw @s {"rawtext":[{"text":"[锚定55年]: 你大限将至，但因为只发掘了4年，所以到现在都一无所获"}]}
execute as @s if score @s jqtime matches 189 run tellraw @s {"rawtext":[{"text":"--你心念一动"}]}
execute as @s if score @s jqtime matches 190 run  replaceitem entity @s slot.weapon.offhand 0 minecraft:totem_of_undying 1 1 {"item_lock":{"mode":"lock_in_slot"}}
execute as @s if score @s jqtime matches 190 run damage @s 100 override
execute as @s if score @s jqtime matches 191 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 191 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 191 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 191 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 191 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 192 run tp @s 313 53 198 
execute as @s if score @s jqtime matches 193 run structure load "gf/yy/千机yhjz" ~~~
execute as @s if score @s jqtime matches 194 run tellraw @s {"rawtext":[{"text":"还真：充能完毕，是否将当前场景虚拟化，回归最初锚点。"}]}
execute as @s if score @s jqtime matches 195 run tellraw @s {"rawtext":[{"text":"【本次模拟结束】(下一世不会清除物品，请放心的肝吧)"}]}
execute as @s if score @s jqtime matches 196 run tellraw @s {"rawtext":[{"text":"【你可以在以下选项中选择一项进行保留：】"}]}
execute as @s if score @s jqtime matches 197 run tellraw @s {"rawtext":[{"text":"1.本次模拟中自身持有的一件物品。"}]}
execute as @s if score @s jqtime matches 198 run tellraw @s {"rawtext":[{"text":"2.本次模拟中自身的修行境界。"}]}
execute as @s if score @s jqtime matches 199 run tellraw @s {"rawtext":[{"text":"3.本次模拟中与自身关系密切的一位人员的模拟记忆。此记忆可让该人员继承。"}]}
execute as @s if score @s jqtime matches 200 run tellraw @s {"rawtext":[{"text":"4.放弃以上选择，加快充能进度"}]}
execute as @s if score @s jqtime matches 203 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 历经多次轮回，终于有点有用的东西了，选择第一项"}]}
execute as @s if score @s jqtime matches 206 run tellraw @s {"rawtext":[{"text":"-这功法变得虚无缥缈了起来"}]}
execute as @s if score @s jqtime matches 210 run tellraw @s {"rawtext":[{"text":"-你惊喜的发现自己就可以随时将功法从【还真】中取出与放回。而且，功法与自己已经实现了某种意义上的绑定关系。\n这门功法已经彻底属于自己了，即使下一世模拟自己没有选择将其带回，它也永久的存在于【还真】之中。"}]}
execute as @s if score @s jqtime matches 217 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 如此一来，倒是可以多了许多谋划……"}]}
execute as @s if score @s jqtime matches 220 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 大迁徙时代已经过去数千年，相关线索早已深埋地下。而大肆挖掘古墓之事实在是过于惊世骇俗，以上一世我对朝堂的掌控力之强，都激起了不小的反对力量。若是朝廷刚定就行此事，必定难以为继。"}]}
execute as @s if score @s jqtime matches 226 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不过，若是我从此刻开始布局，花费二十年时光，未必不能转变天下之人思想。。"}]}
execute as @s if score @s jqtime matches 227 run camera @s fade time 1 2 7 color 0 0 0 

execute as @s if score @s jqtime matches 229 run tp @s 172 59 260
execute as @s if score @s jqtime matches 230 run tag @s add jqa