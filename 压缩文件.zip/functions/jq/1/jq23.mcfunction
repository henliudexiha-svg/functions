execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"如同设定好的程序一般，一切按部就班的进行着。"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"科考，中举，当状元。"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"当县令，开采矿物，造枪。"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"当杀掉琅琊王，取而代之之后。"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"你开始经常派手下从你事先埋藏好的地方“盗墓”"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"挖掘出不少传世经典，《论语》，《易》，《周易》、《周礼》、《礼记》、《仪礼》、《诗经》,以至于属下对你越来越敬佩"}]}
execute as @s at @s if score @s jqtime matches 40 run playsound random.levelup @s
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 40 run scoreboard players set @s rwa 16
execute as @s if score @s jqtime matches 41 run tag @s add jqa 