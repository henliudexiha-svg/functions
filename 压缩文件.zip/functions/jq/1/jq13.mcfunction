execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"-你参加了殿试，果然是状元，由于你乡试、会试、殿试中全都名列第一，连中三元，名动天下！"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"-半年后，以年轻增加资历为由，自请到外地为官。目的地自然还是温县"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-朝堂之上虽多有不解和惋惜，但还是批准了他的请求。"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[锚定3年] 你又来到的温县"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[锚定4年] 由于你的名气太大，加上对县内的大小官员的脾性全都了解的一清二楚。几乎没费什么功夫，你就将温县上下收拾地服服帖帖。"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"[锚定4年] 同年，你打算培育自己的班底，壮大自己的势力。"}]}

execute as @s at @s if score @s jqtime matches 24 run playsound random.levelup @s
execute as @s if score @s jqtime matches 24 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s at @s if score @s jqtime matches 24 run scoreboard players set @s rwa 9
execute as @s if score @s jqtime matches 25 run tag @s add jqa