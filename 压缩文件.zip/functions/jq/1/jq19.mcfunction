execute as @s if score @s jqtime matches 4 run effect @s clear
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: §4仙道亡矣!!!"}]}
execute as @s if score @s jqtime matches 9 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 仙道亡矣……此地，到底出了什么变故；整个修仙界，又到底发生了些什么。"}]}
execute as @s if score @s jqtime matches 10 run camera @s fade time 1 2 1 color 0 0 0 
execute as @s if score @s jqtime matches 12 run tp @s 172 59 260
execute as @s at @s if score @s jqtime matches 14 run playsound random.levelup @s
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 14 run scoreboard players set @s rwa 14

execute as @s if score @s jqtime matches 16 run tag @s add jqa 