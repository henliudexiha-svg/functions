scoreboard players set @s[scores={rwa=13,rw=..12}] jqa 19
tag @s[scores={rwa=13,rw=..12}] add jq
effect @s[scores={rwa=13,rw=..12}] blindness 10 10 true
effect @s[scores={rwa=13,rw=..12}] darkness 100 0 true 
tp @s -283 74 214