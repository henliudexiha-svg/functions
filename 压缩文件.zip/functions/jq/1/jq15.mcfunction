execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"[大学士]：你？你是？"}]}
execute as @s if score @s jqtime matches 7 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 我，哈哈，我就是琅琊王，是琅琊王府的实际控制人"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"[大学士]：不可能，你明明是知府"},{"selector":"@s"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 那又如何，真正的琅琊王，四年前就死了（掌控了整个琅琊王府的事和盘托出）"}]}
execute as @s if score @s jqtime matches 17 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 而且你的孙女也在当晚***"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"[大学士]：你想干什么！"}]}
execute as @s if score @s jqtime matches 24 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 大学士真是爽快人，那我也就直说了，你当政多年，树敌太多，但是你的那几个儿子又是fw，只怕你身故后，恐怕难以护得家族周全"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 但是，你只要在必要时候助我一臂之力，我必定会保大学士家族百年富贵。"}]}
execute as @s if score @s jqtime matches 32 run tellraw @s {"rawtext":[{"text":"[大学士]：emmm"}]}
execute as @s if score @s jqtime matches 34 run tellraw @s {"rawtext":[{"text":"[大学士]：emmmmmmmm"}]}
execute as @s if score @s jqtime matches 36 run tellraw @s {"rawtext":[{"text":"[大学士]：emmmmmmmmmmmm"}]}
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"[大学士]：此事为何事？"}]}
execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哈哈哈，日后自会分晓"}]}
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"-时间很快就过去了"}]}
execute as @s if score @s jqtime matches 47 run camera @s fade time 2 30 2 color 0 0 0
execute as @s if score @s jqtime matches 49 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[锚定10年] 琅琊王妃诞下一子。很显然，这是你的种。你书信一封，前往大学士府报喜"}]}
execute as @s if score @s jqtime matches 54 run tp @s 142 74 104
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"[锚定15年] 皇帝终于病重。得到传位旨意后，你带着心腹，星夜兼程，火速入京。"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[锚定15年] 同年，琅琊王替身继位后，你借着皇帝的旨意，在朝堂上大肆安排心腹。同时有着大学士暗中配合，没起什么波澜，就掌控住了局势。"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"[锚定16年] 各地叛乱四起。你趁机将心腹安插进军队中，之后借着平叛军功，大肆提拔。不过三四年的功夫，军队也被你牢牢掌控。"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[锚定16年] 天下逐渐从帝皇更替的动荡中恢复过来。你此时果断毒杀了假冒的康宁帝，将最后一丝可能的威胁扼杀了摇篮里。"}]}
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"[锚定16年] 同年，你将自己的儿子扶持称帝后，你封自己为太师，由幕后走到台前，再次权倾天下。你比上一世快了整整22年"}]}
execute as @s if score @s jqtime matches 80 run tellraw @s {"rawtext":[{"text":"[锚定35年] 地点: 大玄国-玄京-太师府"}]}
execute as @s if score @s jqtime matches 83 run tellraw @s {"rawtext":[{"text":"[访仙吏] 启禀太师，我们访仙营受命驻扎于墟渊之旁，日夜观察，发现墟渊上的迷雾，每过十五年会散开半日，而且每人所见皆不同，正因如此，派我快马加鞭来此汇报"}]}
execute as @s if score @s jqtime matches 87 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 可有所发现？"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"[访仙吏] 回禀太师，大雾散去之后，依稀有光亮从渊底照出。我们用望远镜观察，竟然发现了种种倒置的景象。当真是不可思议！"}]}
execute as @s if score @s jqtime matches 93 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 那两名修仙者果然来自墟渊(心想)"}]}
execute as @s if score @s jqtime matches 95 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 可探索到深渊底部？"}]}
execute as @s if score @s jqtime matches 98 run tellraw @s {"rawtext":[{"text":"[访仙吏] 回禀太师，属下无能。我们等尝试了各种方法，奈何只要下到一定深度，就被突如其来的罡风割的粉碎，连我们最坚硬的铠甲也不能抵抗片刻。"}]}
execute as @s if score @s jqtime matches 103 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: （摆了摆手让访仙吏回去）寇洪，道玄子，还是要等你们啊。"}]}
execute as @s at @s if score @s jqtime matches 105 run playsound random.levelup @s
execute as @s if score @s jqtime matches 105 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s at @s if score @s jqtime matches 105 run scoreboard players set @s rwa 11
execute as @s if score @s jqtime matches 106 run tag @s add jqa