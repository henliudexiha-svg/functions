execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"[村长弟弟] 好了，再也不敢了，这块田地是你们家的了，我也不打扰你们了"}]}
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"[村长弟弟] 这10个货币就当是赔礼道歉了，你就收下吧，已老实，求放过"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:这还差不多，我也不想和你一般见识（说罢就扬长而去）"}]}
execute as @s if score @s jqtime matches 13 run tellraw @s {"rawtext":[{"text":"心里话：距离乡试还有半年时间，先回家准备准备"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"半年过去了，你与家中日夜苦读，终于迎来了乡试的日子"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 我这次早已经知晓了考题，拿下前3甲不成问题（信心满满的说）"}]}
execute as @s if score @s jqtime matches 25 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 25 run camera @s fade time 2 20 2 color 0 0 0
execute as @s if score @s jqtime matches 27 run tellraw @s {"rawtext":[{"text":"---时间很快就过去了---"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[锚定一年] 你参加了乡试，虽然只是三十多名的末尾成绩，但终归是成功中了举人，光宗耀祖"}]}
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"[锚定二年] 你前往玄京城参加了会试。对试题早有准备的你自然高中。"}]}
execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 最后的殿试就更不在话下了，马上就开始了，先去参加殿试吧"}]}
execute as @s at @s if score @s jqtime matches 46 run playsound random.levelup @s
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 46 run scoreboard players set @s rwa 4
execute as @s if score @s jqtime matches 47 run tag @s add jqa