execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"[琅琊王] 还是你懂我（看了看礼物）"}]}
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哈哈，你喜欢就好"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"[琅琊王] 哈哈，知我者，知府也"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[琅琊王] 来来来，今天大喜之日，你我就喝个三天三夜"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哈哈，知我者，琅琊也"}]}
execute as @s if score @s jqtime matches 20 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 20 run camera @s fade time 2 100 2 color 0 0 0
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"---时间很快就过去了---"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[锚定15年] 皇上突发恶疾。驾崩前宣琅琊王进京，并传位于他。琅琊王继位，改年号宣景"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[锚定16年] 宣景帝召你入京，并提拔你为兵部侍郎。同年，各地同时发生大小叛乱。宣景帝命你领兵平判"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[锚定18年] 你奔波各地，终于将叛军扫荡一空。回京之后，宣景帝收回了你的军权，升你为兵部尚书，领太子太师"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"[锚定20年] 皇后突陷巫蛊案。宣景帝大怒，将其打入冷宫。太子私下找你求救，你果断答应。经过私下走访排查，找到了熹妃诬陷皇后的证据，还了皇后清白。宣景帝夷熹妃三族，却没有将皇后从冷宫放出"}]}
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[锚定21年] 有人暗中告你谋反，并上交了你当年私自开采矿产、暗中掌握一批武装力量的证据。你万分惶恐，上书请罪。宣景帝撤了你的尚书职位，只是让你教导太子"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[锚定23年] 宣景帝春狩，忽然心有所感，决定回江南道琅琊王府看看"}]}
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"[锚定24年] 宣景帝一下江南，命你作陪。在江南游山玩水的同时，还顺便去看了当年你私下开采的几个矿山"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[锚定25年] 宣景帝二下江南。只是这次，他没有带上你。三个月后，你暗中收到消息，有人告发你私下前往冷宫看望皇后之事。同年，宣景帝回京途中被人暗杀。消息传回，京师震动。众官员于冷宫中请出皇后，其后太子继位，年号康宁"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"[锚定26年] 你被加封为太师，领议政阁大学士，位极人臣。皇帝年幼，对你多有依仗。借着这个机会你党同伐异，在朝堂上建立了自己的班底"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[锚定27年] 你的婶婶去世了。你再次产生了觅长生的想法，于是你派人前往各地探访仙人存在的痕迹"}]} 
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"[锚定28年] 皇帝成年了。而你的权势却与日俱增，朝堂上几乎成了你的一言堂"}]} 
execute as @s if score @s jqtime matches 80 run tellraw @s {"rawtext":[{"text":"[锚定30年] 天下人只知太师而不知皇帝"}]} 
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"[锚定31年] 太后怀孕，急召你入宫商议对策。你大喜之下暗中将太后接回太师府好生照顾。同年，太后为你生下了一个儿子"}]} 
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"[锚定33年] 你单独入朝之时，被康宁帝暗中培养的心腹侍卫围住。幸得异宝相助，侥幸捡回一条性命。你大怒，欲弑帝自立。在太后苦苦哀求及身边大臣的劝说之下，没有动手。你尽诛皇帝近臣。此后，康宁帝只有皇帝之名，而无皇帝之实"}]} 
execute as @s if score @s jqtime matches 95 run tellraw @s {"rawtext":[{"text":"[锚定38年] 康宁帝郁郁而终。你立其嫡长子为帝，改元隆昌"}]} 
execute as @s if score @s jqtime matches 100 run tellraw @s {"rawtext":[{"text":"[锚定40年] 太后因病去世。你求仙之心愈发心切"}]} 
execute as @s if score @s jqtime matches 105 run tellraw @s {"rawtext":[{"text":"[锚定45年] 你的妻子去世了"}]} 
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"[锚定46年] 你的大儿子因病去世了"}]} 
execute as @s if score @s jqtime matches 115 run tellraw @s {"rawtext":[{"text":"[锚定48年] 多年求仙无果，你放弃了寻仙的想法,同年你68岁"}]}
execute as @s if score @s jqtime matches 117 run tag @s add jq9 
execute as @s if score @s jqtime matches 117 run kill @e[name=京城守卫] 
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 137 75 87
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 137 75 90
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 137 75 95
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 148 75 87
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 148 75 90
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 148 75 95
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 145 75 105
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 140 75 105
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 146 59 112
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 146 59 117
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 146 59 122
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 146 59 127
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 139 59 112
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 139 59 117
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 139 59 122
execute as @s if score @s jqtime matches 117 run structure load "1/jcsw" 139 59 127
execute as @s if score @s jqtime matches 117.. run tag @e[name=京城守卫] add wy 
execute as @s if score @s jqtime matches 120 run tellraw @s {"rawtext":[{"text":"[锚定50年] ---------------------------------"}]}
execute as @s if score @s jqtime matches 120 run tp @s 142 74 104
execute as @s if score @s jqtime matches 122 run tag @s add jqa