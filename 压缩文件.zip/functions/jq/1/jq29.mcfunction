execute as @s if score @s jqtime matches 1 run camera @s fade time 2 8 2 color 0 0 0
execute as @s if score @s jqtime matches 3 run tp @s 142 74 104
execute as @s if score @s jqtime matches 1 run tag @s add jq9
execute as @s if score @s jqtime matches 1 run kill @e[name=京城守卫] 
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 87
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 90
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 95
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 87
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 90
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 95
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 145 75 105
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 140 75 105
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 112
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 1
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 122
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 127
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 112
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 1
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 122
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 127
execute as @s if score @s jqtime matches 1..34 run tag @e[name=京城守卫] add wy 
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[锚定50年] 地点: 大玄国-玄京-太师府"}]}
execute as @s if score @s jqtime matches 9.. as @e[name=京城守卫] at @s run tp @s ~~~ facing @p 
execute as @s if score @s jqtime matches 9 run tickingarea add 0 59 315 41 58 264 temp 
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-算算时间也快到了"}]}
execute as @s if score @s jqtime matches 19 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 20 run structure load "1/道玄子" 0 86 315
execute as @s if score @s jqtime matches 20 run structure load "1/寇洪" 11 86 305
execute as @s if score @s jqtime matches 20..28 as @e[name=道玄子] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20..28 as @e[name=寇洪] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=道玄子] wy 1
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=寇洪] wy 1
execute as @s if score @s jqtime matches 22 run tag @e[name=道玄子] add wy2
execute as @s if score @s jqtime matches 22 run tag @e[name=寇洪] add wy2
execute as @s if score @s jqtime matches 21..27 at @e[name=道玄子] run camera @s set minecraft:free ease 1 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 at @e[name=道玄子] run camera @s set minecraft:free ease 0.7 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 run tp @s 142 74 104

execute as @s if score @s jqtime matches 28 at @s anchored eyes run camera @s set minecraft:free ease 1 linear pos ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28 at @s run tp @s ~~~ facing @e[name=道玄子] 
execute as @s if score @s jqtime matches 29 run camera @s clear
execute as @s if score @s jqtime matches 28.. as @e[name=寇洪] at @s run tp @s ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28.. as @e[name=道玄子] at @s run tp @s ~~~ facing @e[name=寇洪]
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[寇洪]：道玄子！！！你不要欺人太甚！！！"}]}
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"[道玄子]：把功法交出来！否则我跟你不死不休！"}]}
execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"[寇洪]：笑话，我被困筑基期近百年，眼看大限将至，得此结丹功法，怎么可能交予他人！（冷哼）"}]}
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 区区结丹功法，也值得二位死斗"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[寇洪]：什么人，好大的口气！"}]}
execute as @s if score @s jqtime matches 54 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 二位不妨下来一叙！"}]}
execute as @s if score @s jqtime matches 56 as @e[name=道玄子] run scoreboard players set @s wy 5
execute as @s if score @s jqtime matches 56 as @e[name=寇洪] run scoreboard players set @s wy 5
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 请（哈哈）"}]}
execute as @s if score @s jqtime matches 61 run camera @s fade time 2 10 2 color 0 0 0
execute as @s if score @s jqtime matches 63 as @e[name=京城守卫] at @s run tp @s ~~-100~ 
execute as @s if score @s jqtime matches 63 run kill @e[name=京城守卫]
execute as @s if score @s jqtime matches 63 as @e[name=寇洪] at @s run tp @s ~~-100~ 
execute as @s if score @s jqtime matches 63 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 63 run kill @e[name=道玄子]
execute as @s if score @s jqtime matches 63 run tag @s remove jq9
execute as @s if score @s jqtime matches 63 run tickingarea remove temp
execute as @s if score @s jqtime matches 64 run tag @s add jqa