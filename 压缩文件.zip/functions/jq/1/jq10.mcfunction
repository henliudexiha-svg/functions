execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"地点: 大玄国-玄京-太师府"}]}
execute as @s if score @s jqtime matches 1.. as @e[name=京城守卫] at @s run tp @s ~~~ facing @p 
execute as @s if score @s jqtime matches 1 run tickingarea add 0 59 315 41 58 264 temp 
execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 每一世都在这百年内轮回，这狗系统不要也罢（心里话）"}]}
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"[众臣] ：为太师寿！！！！"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哈哈哈哈，罢了罢了，人生如此，夫复何求！（心里话）"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[一臣] ：快看，那是什么？天降流火，这是祥瑞！快去告予太师！"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[另一臣] ：太师大寿，何人敢在外喧哗！"}]}
execute as @s if score @s jqtime matches 19 run kill @e[name=道玄子]
execute as @s if score @s jqtime matches 19 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 20 run structure load "1/道玄子" 0 86 315
execute as @s if score @s jqtime matches 20 run structure load "1/寇洪" 11 86 305
execute as @s if score @s jqtime matches 20..28 as @e[name=道玄子] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20..28 as @e[name=寇洪] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=道玄子] wy 1
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=寇洪] wy 1
execute as @s if score @s jqtime matches 22 run tag @e[name=道玄子] add wy2
execute as @s if score @s jqtime matches 22 run tag @e[name=寇洪] add wy2
execute as @s if score @s jqtime matches 21..27 at @e[name=道玄子] run camera @s set minecraft:free ease 1 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 at @e[name=道玄子] run camera @s set minecraft:free ease 0.7 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 run tp @s 142 74 104

execute as @s if score @s jqtime matches 28 at @s anchored eyes run camera @s set minecraft:free ease 1 linear pos ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28 at @s run tp @s ~~~ facing @e[name=道玄子] 
execute as @s if score @s jqtime matches 29 run camera @s clear


execute as @s if score @s jqtime matches 28.. as @e[name=寇洪] at @s run tp @s ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28.. as @e[name=道玄子] at @s run tp @s ~~~ facing @e[name=寇洪]
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"[寇洪]：道玄子！！！你不要欺人太甚！！！"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[道玄子]：把功法交出来！否则我跟你不死不休！"}]}
execute as @s if score @s jqtime matches 36 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 修……修仙者！这..这怎么可能……，我派人寻遍世间，根本就找不到一丝一毫仙人痕迹！？？"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"[道玄子]：寇洪，你以为你逃到这仙绝之地，我就会放过你吗？"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"[寇洪]：笑话，我被困筑基期近百年，眼看大限将至，得此结丹功法，怎么可能交予他人！（冷哼）"}]}
execute as @s if score @s jqtime matches 48 run tellraw @s {"rawtext":[{"text":"[道玄子]：金丹大道，有我无他。如今长生法门在前，休怪我无情了！！"}]}
execute as @s if score @s jqtime matches 52 as @e[name=道玄子] at @s run structure load "1/锈剑道玄" ~~~2 
execute as @s if score @s jqtime matches 52 run replaceitem entity @e[name=隐身] slot.weapon.mainhand 1 netherite_sword 1 9999
execute as @s if score @s jqtime matches 52 run tag @e[name=隐身] add wy 
execute as @s if score @s jqtime matches 52 as @e[name=道玄子] run tag @s add yuanxing
execute as @s if score @s jqtime matches 52 as @e[name=道玄子] at @s run tag @e[name=隐身] add yuanhu
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"[寇洪]：可笑你我百年兄弟，如今却为了一线生机拔刀相向！"}]}
execute as @s if score @s jqtime matches 57 run tellraw @s {"rawtext":[{"text":"[道玄子]：哼（冷笑）"}]}
execute as @s if score @s jqtime matches 59 run tellraw @s {"rawtext":[{"text":"[寇洪]：我知我修为不如你，今日想必难逃一劫，但是此地凡人如此之多，却不知道，你是否又能够抵挡得住，如此浓度的仙凡瘴呢！"}]}
execute as @s if score @s jqtime matches 59.. as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~1 ~ 
execute as @s if score @s jqtime matches 59.. as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~1 ~
execute as @s if score @s jqtime matches 59.. as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~1 ~
execute as @s if score @s jqtime matches 59.. as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~1 ~
execute as @s if score @s jqtime matches 59.. as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~1 ~
execute as @s if score @s jqtime matches 59.. as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~1 ~
execute as @s if score @s jqtime matches 63 run tellraw @s {"rawtext":[{"text":"[道玄子]：寇洪，你想干什么！（顿时色变）"}]}
execute as @s if score @s jqtime matches 67 run tellraw @s {"rawtext":[{"text":"[寇洪]：不过是求一线生机罢了！（疯狂地笑）"}]}
execute as @s if score @s jqtime matches 67 as @e[name=寇洪] at @s run playanimation @s animation.player.swim b
execute as @s if score @s jqtime matches 67 run camera @s fade time 1 5 1 color 255 0 0 
execute as @s if score @s jqtime matches 67 run camerashake add @s 4 2
execute as @s if score @s jqtime matches 68 run replaceitem entity @s slot.weapon.offhand 0 minecraft:totem_of_undying 1 1 {"item_lock":{"mode":"lock_in_slot"}}
execute as @s if score @s jqtime matches 69 run damage @s 100 override

execute as @s if score @s jqtime matches 69 run kill @e[name=道玄子]
execute as @s if score @s jqtime matches 69 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 69 run kill @e[name=京城守卫]
execute as @s if score @s jqtime matches 69 at @e[name=隐身] run tp @e[name=隐身] ~ -100 ~
execute as @s if score @s jqtime matches 70 run kill @e[name=隐身]

execute as @s if score @s jqtime matches 75 run tp @s 313 53 198 
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 72 run tellraw @s {"rawtext":[{"text":"还真：充能完毕，是否将当前场景虚拟化，回归最初锚点。"}]}
execute as @s if score @s jqtime matches 76 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哼，道玄子，寇洪五十年后，我在玄京城等你们（心里话）"}]}
execute as @s if score @s jqtime matches 79 run tellraw @s {"rawtext":[{"text":"【本次模拟结束】(下一世不会清除枪以外的物品，请放心的肝吧)"}]}
execute as @s if score @s jqtime matches 80 run tellraw @s {"rawtext":[{"text":"【你可以在以下选项中选择一项进行保留：】"}]}
execute as @s if score @s jqtime matches 81 run tellraw @s {"rawtext":[{"text":"1.本次模拟中自身持有的物品。"}]}
execute as @s if score @s jqtime matches 82 run tellraw @s {"rawtext":[{"text":"2.本次模拟中自身的修行境界。"}]}
execute as @s if score @s jqtime matches 83 run tellraw @s {"rawtext":[{"text":"3.本次模拟中与自身关系密切的一位人员的模拟记忆。此记忆可让该人员继承。。"}]}
execute as @s if score @s jqtime matches 84 run tellraw @s {"rawtext":[{"text":"4.放弃以上选择，加快充能进度"}]}
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这回档功能要20年才能充满使用，还是选择加快进度稳妥。"}]}
execute as @s if score @s jqtime matches 85 run clear @s
execute as @s if score @s jqtime matches 86 run give @s gold:hz_1 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
execute as @s if score @s jqtime matches 88 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这一世，我要捕仙，以有心算无心，就算他们是所谓的筑基期强者，我也未必没有胜算。"}]}
execute as @s if score @s jqtime matches 89 run camera @s fade time 1 2 7 color 0 0 0 

execute as @s if score @s jqtime matches 93 run tp @s 172 59 260
execute as @s if score @s jqtime matches 93 run tag @s remove jq9
execute as @s if score @s jqtime matches 93 run tickingarea remove temp
execute as @s if score @s jqtime matches 94 run tag @s add jqa