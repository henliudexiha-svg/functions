execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 或许我能依仗的，除了枪炮火药之外，还有他们口中的仙凡瘴……"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 另外，五十年时间，我也不能干等。他们是从东方墟渊而来，或许我可以先派人深入墟渊底部，一探究竟。"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不过，还得注重当下，当下最要紧的还是科举。多了数十年的当权经历，写出的文章肯定是远超上一世"}]}
execute as @s at @s if score @s jqtime matches 14 run playsound random.levelup @s
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s at @s if score @s jqtime matches 14 run scoreboard players set @s rwa 7
execute as @s if score @s jqtime matches 15 run tag @s add jqa