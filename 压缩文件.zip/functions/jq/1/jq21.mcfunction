execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"[锚定50年] 地点: 太师府密室"}]}
execute as @s if score @s jqtime matches 1 run structure load "1/寇洪" 176 60 195
execute as @s if score @s jqtime matches 2 as @e[name=寇洪] run playanimation @s animation.humanoid.riding.legs.v1.0 b 99
execute as @s if score @s jqtime matches 2 as @e[name=寇洪] at @s run tp @s ~~~ facing @p
execute as @s if score @s jqtime matches 2 run tp @s ~~~ facing @e[name=寇洪,c=1]
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 仙师说无法带凡人，离开这仙绝之地，难道真无半点可能？"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[寇洪]：你区区一介凡人，我骗你作甚？"}]}
execute as @s if score @s jqtime matches 17 run tellraw @s {"rawtext":[{"text":"[寇洪]：或许金丹期的修士能够护着凡人闯过那绝仙大阵，倘若光是筑基期的修为，绝无可能！"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 难道，我等凡人就没有希望离开此方世界了嘛？"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[寇洪]：你都半截身子都入土的年龄了，还这么执着离开这里作甚，当个土皇帝蛮好的"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 老朽也是想给子孙后代留个念想，若是我的后人修行到如同仙师一般，是否有可能离开这里。"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[寇洪]：哈哈哈哈，不说此地没有丝毫灵气，单说仙凡永隔，此地凡人浑身沾满瘴气，如何能修仙道？"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[寇洪]：除非先去外界洗去一身瘴气"}]}
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 仙凡永隔.。。。。仙凡永隔。。。。。这么说真是一点办法也没有了？"}]}
execute as @s if score @s jqtime matches 43 run tellraw @s {"rawtext":[{"text":"[寇洪]：一点也没有！"}]}
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 唉，仙师若没有吩咐，老夫便告辞了"}]}
execute as @s if score @s jqtime matches 49 run tp @s 177.53 60.00 200.9 facing @e[name=寇洪,c=1]
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~2.5 ~
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~1 ~2.5 ~
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~-1 ~2.5 ~
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~2.5 ~-1
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~ ~2.5 ~1
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~1 ~2.5 ~1
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~1 ~2.5 ~-1
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~-1 ~2.5 ~1
execute as @s if score @s jqtime matches 50..53 as @e[name=寇洪] at @s run particle minecraft:trial_spawner_detection ~-1 ~2.5 ~-1
execute as @s if score @s jqtime matches 52 run tellraw @s {"rawtext":[{"text":"[寇洪]：仙凡瘴？？！！！你什么意思"}]}
execute as @s if score @s jqtime matches 53 as @e[name=寇洪] run playanimation @s animation.cow.setup.v1.0 b 999
execute as @s if score @s jqtime matches 53 as @e[name=寇洪] at @s run tp @s ~~-1~
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哼，既然仙凡不两立，那我一介凡人，又怎么敢完全相信你说的话？来人！！把他押下去"}]}
execute as @s if score @s jqtime matches 56 run camera @s fade time 1 4 2 color 0 0 0 
execute as @s if score @s jqtime matches 57 run kill @e[name=寇洪]
execute as @s at @s if score @s jqtime matches 58 run playsound random.levelup @s
execute as @s if score @s jqtime matches 58 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 58 run scoreboard players set @s rwa 15
execute as @s if score @s jqtime matches 59 run tag @s add jqa
