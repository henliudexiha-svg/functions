execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"【本次模拟结束】"}]}
execute as @s if score @s jqtime matches 2 run tellraw @s {"rawtext":[{"text":"【你可以在以下选项中选择一项进行保留：】"}]}
execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"1.本次模拟中自身持有的一件物品。"}]}
execute as @s if score @s jqtime matches 4 run tellraw @s {"rawtext":[{"text":"2.本次模拟中自身的修行境界。"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"3.本次模拟中与自身关系密切的一位人员的模拟记忆。此记忆可让该人员继承。。"}]}
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"4.放弃以上选择，加快充能进度"}]}
execute as @s if score @s jqtime matches 7 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:我没死？？？"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:这是哪？？？"}]}
execute as @s if score @s jqtime matches 11 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:这保留自己修为境界是什么意思，难不成这里是修仙世界？"}]}
execute as @s if score @s jqtime matches 16 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:那为什么我临终前没有看到一丝丝修仙痕迹。"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:......"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:充能没满会怎么样！"}]}
execute as @s if score @s jqtime matches 27 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:加快充能进度！"}]}
execute as @s if score @s jqtime matches 27 run camera @s fade time 0 2 7 color 0 0 0 
execute as @s if score @s jqtime matches 27 run tp @s 172 59 260
execute as @s  as @s if score @s jqtime matches 27 run spawnpoint @s ~~~ 
execute as @s if score @s jqtime matches 27 run tag @s add jqa