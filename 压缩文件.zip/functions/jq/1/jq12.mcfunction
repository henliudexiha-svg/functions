execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"-半年后，你果真榜上有名，名列第一。"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"-又半年后，你参加会试，你果真榜上有名，名列第一。"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 有了两世经验，这考试易如反掌"}]}
execute as @s at @s if score @s jqtime matches 14 run playsound random.levelup @s
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s at @s if score @s jqtime matches 14 run scoreboard players set @s rwa 8
execute as @s if score @s jqtime matches 15 run tag @s add jqa