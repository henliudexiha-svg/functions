execute as @s[scores={rwa=23,rw=..22}] run tellraw @a {"rawtext":[{"text":"[§e§l成就§f§l] 玩家"},{"selector":"@s"},{"text":" 闯过§4§l仙绝大阵§f，从此修仙有望！！！"}]}
execute as @s[scores={rwa=23,rw=..22}] run playsound random.levelup @a ~~~ 1 0.2
execute as @s[scores={rwa=23,rw=..22}] run tag @s add rw 
execute as @s[scores={rw=23}] run tp @s 3362 -5 3148
