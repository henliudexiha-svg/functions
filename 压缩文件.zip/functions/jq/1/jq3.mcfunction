execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:这是???"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:我重生了，我居然重生了，哈哈哈哈哈！！！！！！"}]}
execute as @s if score @s jqtime matches 11 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:凭借我前世记忆，多次轮回，这方世界岂不成我的玩物，哈哈哈哈哈！！！！！！"}]}
execute as @s if score @s jqtime matches 16 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:那为什么我临终前没有看到一丝丝修仙痕迹。"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:哈哈哈哈哈哈哈哈哈哈哈！！！"}]}
execute as @s if score @s jqtime matches 21 run give @s gold:hz_1 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[还真]:还真充能完毕！"}]}
execute as @s if score @s jqtime matches 26 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:眼下还是要把科举考了，不过我前世熟读10年，这几年题目我都还记得，科举不手到擒来。"}]}
execute as @s at @s if score @s jqtime matches 30 run playsound random.levelup @s
execute as @s if score @s jqtime matches 30 run scoreboard players set @s rwa 1 
execute as @s if score @s jqtime matches 31 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 31 run tag @s add jqa