execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[心腹] 要我偷偷下药，把皇帝毒杀？"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这毒药无色无味，像水一样，你要小心谨慎，一定不要被发现,一定要多下点"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[心腹] 明白"}]}
execute as @s if score @s jqtime matches 17 run tellraw @s {"rawtext":[{"text":"[锚定六年] 由于你的决定，心腹下药的没有被发现"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"[锚定六年] 同年，皇帝突患重疾，卧病在床。众太医均无计可施。"}]}
execute as @s at @s if score @s jqtime matches 25 run playsound random.levelup @s
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 25 run scoreboard players set @s rwa 18
execute as @s if score @s jqtime matches 26 run tag @s add jqa 
