execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 果然是仙家手段，这地面看似像星空"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这墓碑看上去好像有什么字"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 太衍宗外门弟子伊行之墓？"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 死前还念念不忘自己的宗门，不以皇帝而始终以太衍宗外门弟子的身份自居"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 按照寇洪之前的说法，天下宗门应该在大迁徙时代之前的大劫中尽数消散了才是。现在看来，这其中应当另有隐情（心里话）"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不知能不能找到，当时迁移用的飞舟"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[旁边的大臣]: 启禀太师，我们在周边陪葬墓室的陪葬品清单中，找到了有关飞舟字样的记录。但是这处墓室已经被盗，根据破坏痕迹判断，应当是数千年发生的"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 又是如此！每每让我看到了希望，却又终是镜花水月！"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 继续查！！大大小小的墓，一个都不要放过"}]}
execute as @s if score @s jqtime matches 49 run tellraw @s {"rawtext":[{"text":"-最终还是没找到"}]}
execute as @s if score @s jqtime matches 54 run tellraw @s {"rawtext":[{"text":"-时间很快就过去了"}]}
execute as @s if score @s jqtime matches 59 run tellraw @s {"rawtext":[{"text":"[锚定30年] 过了10年"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"[大臣]: 启禀太师，发现仙人之墓，在一处偏僻的山谷中。还没发掘，就被莫名的力量所伤，死伤惨重。虽有众多极具经验的老手与全副武装的士兵联手，亦不能撼动此小墓分毫。"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 竟有此事？"}]}
execute as @s at @s if score @s jqtime matches 75 run playsound random.levelup @s
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 75 run scoreboard players set @s rwa 20
execute as @s if score @s jqtime matches 76 run tag @s add jqa 