execute as @s if score @s jqtime matches 1 run scoreboard players set @s wy 1
execute as @s if score @s jqtime matches 1 run tag @s add wy2
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：按照寇洪所说，缓慢穿过这层黑暗层，就是修仙界了！"}]}
execute as @s at @s if score @s jqtime matches 20 run playsound random.levelup @s
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 20 run scoreboard players set @s rwa 23
execute as @s if score @s jqtime matches 16 run tag @s remove wy2
execute as @s if score @s jqtime matches 16 run scoreboard players set @s wy 0
execute as @s if score @s jqtime matches 18 run effect @s darkness infinite 0 true
execute as @s if score @s jqtime matches 21 run tag @s add jqa