execute as @s if score @s jqtime matches 1 run tp @s 100 59 85
execute as @s if score @s jqtime matches 2 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 2 run structure load "1/寇洪" 92 59 85 
execute as @s if score @s jqtime matches 2 run structure load "1/道玄子" 95 59 85 
execute as @s if score @s jqtime matches 2 as @e[name=寇洪] at @s run tp @s ~~~ facing @p
execute as @s if score @s jqtime matches 2 as @e[name=道玄子] at @s run tp @s ~~~ facing @p
execute as @s if score @s jqtime matches 3 as @e[name=寇洪] run playanimation @s animation.humanoid.riding.legs.v1.0 b 999
execute as @s if score @s jqtime matches 3 as @e[name=道玄子] run playanimation @s animation.humanoid.riding.legs.v1.0 b 999
execute as @s if score @s jqtime matches 5 run clear @s book 10 1
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：当年先祖临终时曾言，后世或有二人自墟渊东来，踏临京城，乃是我族脱离此地的契机。"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：（哈哈）数千年来，我族中人一直半信半疑。今日得证，当浮一大白！"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"[寇洪] 不知足下如何称呼？(客气)"}]}
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：老夫"},{"selector":"@s"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[道玄子]：足下的先祖数千年前，就遇见到我们二人会来？"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：怎么？二位不信？"}]}
execute as @s if score @s jqtime matches 34 run tellraw @s {"rawtext":[{"text":"[寇洪]：此事太过玄奇，我二人闯荡修仙界百载，也没听说过什么推衍之术能预测千年以后事情的。"}]}
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：不知二位可曾听说过太衍宗？"}]}
execute as @s if score @s jqtime matches 43 run tellraw @s {"rawtext":[{"text":"[道玄子]：难道上古之时，那个以推衍之术闻名天下的宗门？"}]}
execute as @s if score @s jqtime matches 47 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：老夫先祖，正是太衍宗门人。"}]}
execute as @s if score @s jqtime matches 51 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：当初先祖负责迁移凡人一事，奈何尘缘未了，就随家族留在了此地"}]}
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"[寇洪]：太衍宗在大迁徙时代时还存于世？我听闻上古宗门，皆在之前的天地大劫中破灭了。"}]}
execute as @s if score @s jqtime matches 59 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：虽说仙法不能同修，可太衍宗内功法浩如星海，一人分得一门又岂是什么难事？"}]}
execute as @s if score @s jqtime matches 64 run tellraw @s {"rawtext":[{"text":"[道玄子]：浩如星海！"}]}
execute as @s if score @s jqtime matches 67 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：我观二位言语，外界太衍宗似乎许久没有现世了？"}]}
execute as @s if score @s jqtime matches 71 run tellraw @s {"rawtext":[{"text":"[寇洪]：不止太衍宗，包括太上宗、大道宗、天剑派这些上古宗门，如今全都没了踪影。"}]}
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：仙道艰难。果真如先祖所说，宗门也选择隐世避祸了……"}]}
execute as @s if score @s jqtime matches 79 run tellraw @s {"rawtext":[{"text":"[道玄子]：不知道友拦下我二人所为何事？"}]}
execute as @s if score @s jqtime matches 83 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：二位说先祖预言之人，乃我族脱困契机所在，眼见你们要为了一结丹功法生死相向，这才赶忙出言劝阻。"}]}
execute as @s if score @s jqtime matches 88 run tellraw @s {"rawtext":[{"text":"[道玄子]：让道友见笑了。不过你可能不知，外界功法难得，为了一卷功法而反目厮杀，实属正常。"}]}
execute as @s if score @s jqtime matches 92 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：何至于此！"}]}
execute as @s if score @s jqtime matches 95 run tellraw @s {"rawtext":[{"text":"[道玄子]：听道友语气，似乎...."}]}
execute as @s if score @s jqtime matches 98 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：不错，先祖临终前曾传下一卷功法，直指金丹境。"}]}
execute as @s if score @s jqtime matches 103 run tellraw @s {"rawtext":[{"text":"[道玄子]：emm...不知道友所求何事？"}]}
execute as @s if score @s jqtime matches 105 run tellraw @s {"rawtext":[{"text":"[寇洪]：太好了。若是你能得此功法，我们兄弟二人也不需再争斗了。"}]}
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：先祖临终前还留下一法器，名曰---太衍舟，虽然损坏，但先祖曾推算过，来此地的两人，一位擅长使剑，另一位喜爱炼器，可助后人修复太衍舟，脱离此处绝地。"}]}
execute as @s if score @s jqtime matches 116 run tellraw @s {"rawtext":[{"text":"[道玄子]：（震惊）我兄寇洪心醉炼器之道，而我之所长正是剑法。当真是不可思议"}]}
execute as @s if score @s jqtime matches 120 run tellraw @s {"rawtext":[{"text":"[寇洪]：如此莫测神威，真是难以想象……"}]}
execute as @s if score @s jqtime matches 124 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：口说无凭，还先请二位随我来一观这功法。"}]}
execute as @s if score @s jqtime matches 126 as @e[name=寇洪] run playanimation @s animation.humanoid.move b 0
execute as @s if score @s jqtime matches 126 as @e[name=道玄子] run playanimation @s animation.humanoid.move b 0
execute as @s if score @s jqtime matches 128 run tellraw @s {"rawtext":[{"text":"[道玄子]：怎么，你已经得了一篇结丹功法，还不知足？"}]}
execute as @s if score @s jqtime matches 131 run tellraw @s {"rawtext":[{"text":"[寇洪]：好吧，我就不去了"}]}
execute as @s if score @s jqtime matches 132 as @e[name=寇洪] run playanimation @s animation.humanoid.riding.legs.v1.0 b 999
execute as @s if score @s jqtime matches 133 run camera @s set minecraft:free ease 2 linear pos 95 60.8 79 rot 10 180
execute as @s if score @s jqtime matches 134 as @e[name=道玄子] run scoreboard players set @s wy 6
execute as @s if score @s jqtime matches 135 as @e[name=道玄子] at @s run tp @s ~~~~ 180
execute as @s if score @s jqtime matches 135 run camera @s set minecraft:free ease 2 linear pos 95 60.8 68 rot 10 180
execute as @s if score @s jqtime matches 137 run camera @s set minecraft:free ease 1 linear pos 98 60.8 68 rot 10 150
execute as @s if score @s jqtime matches 138 run tp @s 98 59 68
execute as @s if score @s jqtime matches 138 run camera @s clear 
execute as @s if score @s jqtime matches 145 as @e[name=道玄子] run playanimation @s animation.armadillo.rolled_up a 1
execute as @s if score @s jqtime matches 146 run tellraw @s {"rawtext":[{"text":"[道玄子]：这上面全是仙凡瘴？"}]}
execute as @s if score @s jqtime matches 150 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：我等凡人，为了守护家族至宝，也只有如此行事了。"}]}
execute as @s if score @s jqtime matches 154 run tellraw @s {"rawtext":[{"text":"[道玄子]：请道友尽快拿出功法一观吧"}]}
execute as @s if score @s jqtime matches 156 run structure load "gf/yy/千机yhjz" 95 59 62
execute as @s if score @s jqtime matches 158 run tellraw @s {"rawtext":[{"text":"[道玄子]：《千机玉寰金章》，元婴功法！竟然是元婴功法！！！"}]}
execute as @s if score @s jqtime matches 159 as @e[name=道玄子] run playanimation @s animation.armor_stand.athena_pose a 99
execute as @s if score @s jqtime matches 160 as @e[name=道玄子] run playanimation @s animation.armor_stand.athena_pose a 0 
execute as @s if score @s jqtime matches 160 positioned 95 59 62 run kill @e[r=1,type=item]
execute as @s if score @s jqtime matches 163 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：怎么样？老朽所言属实否？"}]}
execute as @s if score @s jqtime matches 166 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：先前只说是结丹功法，就是怕你那兄长再起歹念。"}]}
execute as @s if score @s jqtime matches 170 run tellraw @s {"rawtext":[{"text":"[道玄子]：道友心思缜密，在下佩服。"}]}
execute as @s if score @s jqtime matches 172 run tellraw @s {"rawtext":[{"text":"[道玄子]：我定劝寇洪全力助道友修复太衍舟"}]}
execute as @s if score @s jqtime matches 176 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：那就有劳道友了，事成之后，元婴功法我定当双手奉上。"}]}
execute as @s if score @s jqtime matches 177 run clear @s minecraft:acacia_door 
execute as @s if score @s jqtime matches 177 run camera @s fade time 2 10 2 color 0 0 0
execute as @s if score @s jqtime matches 179 run kill @e[name=寇洪,x=92,y=59,z=85,r=30]
execute as @s if score @s jqtime matches 179 run kill @e[name=道玄子,x=92,y=59,z=85,r=30]
execute as @s if score @s jqtime matches 180 run tag @s add jqa