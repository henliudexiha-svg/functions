execute as @s if score @s jqtime matches 1 run camera @s fade time 2 3 2 color 0 0 0
execute as @s if score @s jqtime matches 4 run tp @s 246 46 276
execute as @s if score @s jqtime matches 5 run structure load "1/钱宏" 238 54 285
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-跑酷过去，即可拿到物品"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 飞舟，果然是飞舟"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这石碑是何物"}]}
execute as @s if score @s jqtime matches 20 run playsound place.amethyst_cluster @s
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"[还真]: 发现可充能物品--止步残碑"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"[还真]: 是否进行充能"}]}
execute as @s if score @s jqtime matches 26 run tellraw @s {"rawtext":[{"text":"--你不受控制的充能，像“还真“饥渴一样"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[还真]: 充能完毕--当前定锚充能进度:25%"}]}
execute as @s if score @s jqtime matches 34 run tellraw @s {"rawtext":[{"text":"[还真]: 当前锚点数量：1"}]}
execute as @s if score @s jqtime matches 38 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 要是能够开启第2锚点，那真是方便太多了（心里话）"}]}
execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 原来这墓主人是筑基修士，被追杀躲进这仙绝知道"}]}
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 反被困在此地，最终也打起这飞舟的主意，没想到这飞舟核心阵法已经被破坏"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这太衍舟我们不会修，但是有人会"}]}
execute as @s at @s if score @s jqtime matches 57 run playsound random.levelup @s
execute as @s if score @s jqtime matches 57 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 57 run scoreboard players set @s rwa 21
execute as @s if score @s jqtime matches 58 run tag @s add jqa 