execute as @s if score @s jqtime matches 1 run camera @s fade time 2 120 2 color 0 0 0
execute as @s if score @s jqtime matches 3 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[锚定六年] 同年，皇帝突患重疾，卧病在床。众太医均无计可施。"}]}
execute as @s if score @s jqtime matches 9 run tellraw @s {"rawtext":[{"text":"[锚定六年] 访古学派持一丹药面圣。言此丹乃是从一古墓中寻得，疑是仙人所留，有活死人肉白骨之效。服之或可解危。"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[锚定六年] 天子先是没有理睬，可随着他的身子一日不如一日，眼看就要行将就木，他还是抱着死马当活马医的心态，将丹药服下。"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[锚定六年] 谁曾想丹药果然有神效，不过几日，天子就恢复如初。"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"[锚定六年] 朝野震动，群臣议论纷纷。同年，皇帝夜诏访古学派领袖进宫，细问仙人之事，一连数日没有上朝。"}]}
execute as @s if score @s jqtime matches 28 run tellraw @s {"rawtext":[{"text":"[锚定六年] 从此之后，皇帝便笃信仙人之存在。暗中授意军中心腹，配合访古学派，于古墓中寻找仙人痕迹。"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[锚定九年] 访古学派于玄京城中举行了一次展览，邀请朝中大臣与京中王公贵族观看。"}]}
execute as @s if score @s jqtime matches 38 run tellraw @s {"rawtext":[{"text":"[锚定九年] 虽然这些人也是富贵非常、见多识广，但看到了展览中一件件稀世珍宝之后，也全都是沉浸其中，流连忘返。"}]}
execute as @s if score @s jqtime matches 43 run tellraw @s {"rawtext":[{"text":"[锚定十年] 访古学派更是放开限制，寻常百姓只要购买门票，便可进入其中一观。"}]}
execute as @s if score @s jqtime matches 48 run tellraw @s {"rawtext":[{"text":"[锚定十年] 玄京城顿时轰动。　无数人排着队，想要进入展览中一窥宝物。人数之多，竟然引得京师道路堵塞。幸得圣上发令，有戍卫营持甲维持秩序，才没有引起更大的骚乱。"}]}
execute as @s if score @s jqtime matches 53 run tellraw @s {"rawtext":[{"text":"[锚定11年] 江淮府破获了一起恶性盗墓案，抓获了上百人的盗墓团队。这伙人于深山中大肆发掘古墓，造成了无法估量的损失。按律，这伙人应当全部被处以极刑。但是案发人数众多，牵连太广，江淮府知府的你不敢擅自做主，上书一封，八百里加急送入玄京城，请圣上决断。"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[锚定11年] 足足过了一月，皇帝的旨意才姗姗来迟。没有判处极刑，只判了尽发为奴，收于京中。朝中大臣也都几乎没有上书反对。"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"[锚定11年] 你看着诏书，微微一笑，知道大势已成。"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[锚定13年] 又有《尚书》、《诗》、《礼》等古籍面世，天下读书人对于那段遗失的历史愈发向往。"}]}
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"[锚定15年] 皇帝有被你属下下药。欲再求仙丹续命，遂发军队十余万，四处发掘古墓，寻找仙丹痕迹。朝臣虽多有微辞，但也没有大规模上书反对。"}]}
execute as @s if score @s jqtime matches 80 run tellraw @s {"rawtext":[{"text":"[锚定15年] 可惜仙丹难寻。年末，皇帝抱憾而终。临终前传位于琅琊王。"}]}
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"[锚定16年] 你再次权倾天下。你为了找到长生线索，推动天下访古寻墓之风愈盛，开启全民大掘墓时代，发掘出的朝代越早，封的官越大"}]}
execute as @s if score @s jqtime matches 92 run tellraw @s {"rawtext":[{"text":"[锚定17年] 一山间猎户，因寻得一方古墓，搏得太师欢心，得封列候。此后，天下人对于访古一事更加热衷与疯狂。无论多么偏僻的山林里，都能看到成群结队的访古者。"}]}
execute as @s if score @s jqtime matches 97 run tellraw @s {"rawtext":[{"text":"[锚定18年] 越来越多人加入访古学派，都立誓要成为掘墓王，都说：我是要成为掘墓王的男人。。"}]}
execute as @s if score @s jqtime matches 103 run tellraw @s {"rawtext":[{"text":"[锚定20年] 随着一座座古墓被发掘，之前遗失的历史也逐渐被补全。6000-7000年前的朝代称为启朝，基本和能和大迁徙时代对上了。"}]}
execute as @s if score @s jqtime matches 108 run tellraw @s {"rawtext":[{"text":"[锚定25年] -----"}]}
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"[大臣] 启禀太师，启朝第一任皇帝，伊行之墓已被被找到"}]}
execute as @s if score @s jqtime matches 115 run tellraw @s {"rawtext":[{"text":"[大臣] 根据访古学派多年的调查，这启朝便是能找到的最早朝代"}]}
execute as @s if score @s jqtime matches 120 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 封锁周边，我要亲自去探查！"}]}
execute as @s at @s if score @s jqtime matches 125 run playsound random.levelup @s
execute as @s if score @s jqtime matches 125 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 125 run scoreboard players set @s rwa 19
execute as @s if score @s jqtime matches 126 run tag @s add jqa 