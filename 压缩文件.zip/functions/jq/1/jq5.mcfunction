execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不错，有了这些装备，别的不说，至少可以给村长的弟弟一个下马威"}]}
execute as @s if score @s jqtime matches 9 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 村长家就在我家对面，他弟弟应该也在那里，这次我要提前去找他给个教训，让他不敢打我家祖传的肥沃田地的主意"}]}
execute as @s at @s if score @s jqtime matches 12 run camera @s set minecraft:free  ease 3 linear pos ~~20~ facing 122 58 266 
execute as @s at @s if score @s jqtime matches 12 run inputpermission set @s movement disabled
execute as @s at @s if score @s jqtime matches 12 run hud @s hide all
execute as @s at @s if score @s jqtime matches 16 run camera @s set minecraft:free  ease 11 out_circ pos 127 60 266 rot 20 90
execute as @s if score @s jqtime matches 19 run scoreboard players set @s rwa 3 
execute as @s at @s if score @s jqtime matches 19 run playsound random.levelup @s
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 28 run camera @s fade time 1 2 1 color 0 0 0
execute as @s if score @s jqtime matches 30 run tag @s add jqa