execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"-你本是华夏学子，但是不知什么原因穿越到古代，这个穷苦书生上"}]}
execute as @s if score @s jqtime matches 5 run effect @s poison infinite 10 true
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"-你本想要依靠现代知识在这古代闯下一番事业。"}]}
execute as @s if score @s jqtime matches 7 run tellraw @s {"rawtext":[{"text":"-没想到这八股文看不了一点。虽然心有大志，三十岁后终于放弃了读书做官的想法。经营起了小本生意，凭借现代经商，当了个普通的富家翁，随后娶妻生子"}]}
execute as @s if score @s jqtime matches 13 run tellraw @s {"rawtext":[{"text":"-现在你已经垂垂老矣，病倒在床上，虽然这病在现代随手可治，但是你学艺不精，加上古代落后"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:我这一生呀。。。。"}]}
execute as @s if score @s jqtime matches 18 run camera @s fade time 0.1 0.8 0.2 color 255 0 0
execute as @s if score @s jqtime matches 19 run replaceitem entity @s slot.weapon.offhand 0 minecraft:totem_of_undying 1 1 {"item_lock":{"mode":"lock_in_slot"}}
execute as @s if score @s jqtime matches 19 run damage @s 100
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"还真：是否将当前场景虚拟化，回归最初锚点。"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:?"}]}
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]:是？"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"-眼前场景坍塌，回到一个不知名空间。"}]}
execute as @s if score @s jqtime matches 23 run tp @s 248 59 413 90 30
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"系统：看看新手教程吧！"}]}
execute as @s if score @s jqtime matches 25 run tag @s add jqa