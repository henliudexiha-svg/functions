execute as @s if score @s jqtime matches 1 run camera @s fade time 2 8 2 color 0 0 0
execute as @s if score @s jqtime matches 3 run tp @s 142 74 104
execute as @s if score @s jqtime matches 1 run tag @s add jq9
execute as @s if score @s jqtime matches 1 run kill @e[name=京城守卫] 
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 87
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 90
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 95
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 87
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 90
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 95
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 145 75 105
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 140 75 105
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 112
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 1
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 122
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 127
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 139 59 112
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 139 59 1
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 139 59 122
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 139 59 127
execute as @s if score @s jqtime matches 1..34 run tag @e[name=京城守卫] add wy 
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[锚定50年] 地点: 大玄国-玄京-太师府"}]}
execute as @s if score @s jqtime matches 9.. as @e[name=京城守卫] at @s run tp @s ~~~ facing @p 
execute as @s if score @s jqtime matches 9 run tickingarea add 0 59 315 41 58 264 temp 
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-往日无比热闹的玄京城如今寂静地有些诡异。"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"-如今的玄京城的大街小巷里，埋伏着他这些年来精心准备的用来对付两位仙人的特殊部队。"}]}
execute as @s if score @s jqtime matches 19 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 20 run structure load "1/道玄子" 0 86 315
execute as @s if score @s jqtime matches 20 run structure load "1/寇洪" 11 86 305
execute as @s if score @s jqtime matches 20..28 as @e[name=道玄子] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20..28 as @e[name=寇洪] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=道玄子] wy 1
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=寇洪] wy 1
execute as @s if score @s jqtime matches 22 run tag @e[name=道玄子] add wy2
execute as @s if score @s jqtime matches 22 run tag @e[name=寇洪] add wy2
execute as @s if score @s jqtime matches 21..27 at @e[name=道玄子] run camera @s set minecraft:free ease 1 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 at @e[name=道玄子] run camera @s set minecraft:free ease 0.7 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 run tp @s 142 74 104

execute as @s if score @s jqtime matches 28 at @s anchored eyes run camera @s set minecraft:free ease 1 linear pos ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28 at @s run tp @s ~~~ facing @e[name=道玄子] 
execute as @s if score @s jqtime matches 29 run camera @s clear
execute as @s if score @s jqtime matches 28.. as @e[name=寇洪] at @s run tp @s ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28.. as @e[name=道玄子] at @s run tp @s ~~~ facing @e[name=寇洪]
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[寇洪]：道玄子！！！你不要欺人太甚！！！"}]}
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s run tp @s ~~~ facing @e[name=寇洪,c=1]
execute as @s if score @s jqtime matches 35 run playsound mob.zombie.woodbreak @s ~ ~ ~ 9 7 25
execute as @s if score @s jqtime matches 35 run playsound mob.snowgolem.hurt @a[r=50] ~~~ 1 4
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^1
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^2
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^3
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^4
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^5
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^6
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^7
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^8
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^9
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^10
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^11
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^12
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^13
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^14
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^15
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^16
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^17
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^18
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^19
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^20
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^21
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^22
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^23
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^24
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^25
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^26
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^27
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^28
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^29
execute as @s if score @s jqtime matches 35 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_crit_particle ^^^30
execute as @s if score @s jqtime matches 35 at @e[name=寇洪] run particle minecraft:breeze_wind_explosion_emitter ~ ~1 ~
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"[寇洪]：咦，这是什么法器？"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"[道玄子]：区区凡人，竟敢对我等修仙者动手。"}]}
execute as @s if score @s jqtime matches 39..45 as @e[name=寇洪] at @s run tp @s ~~~ facing  @e[c=1,name=京城守卫]
execute as @s if score @s jqtime matches 39 as @e[name=寇洪] run playanimation @s animation.humanoid.brushing b
execute as @s if score @s jqtime matches 39 as @e[name=寇洪] at @s run scoreboard players set @e[c=1,name=京城守卫] wy 1
execute as @s if score @s jqtime matches 43 as @e[name=寇洪] at @s run scoreboard players set @e[c=1,name=京城守卫] wy 2
execute as @s if score @s jqtime matches 43 as @e[name=寇洪] at @s run replaceitem entity @s slot.weapon.mainhand 0 minecraft:fishing_rod 
execute as @s if score @s jqtime matches 43 as @e[name=寇洪] at @s run replaceitem entity @e[c=1,name=京城守卫] slot.weapon.mainhand 0 air
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[寇洪]：有点意思，以精巧的机械结构代替法阵，以凡物的爆炸之力代替灵力，居然能爆发出炼气初期的力量……"}]}
execute as @s if score @s jqtime matches 48 as @e[name=寇洪] run playanimation @s animation.sniffer.stand_up b 
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[寇洪]：没想到，几千年过去，被放逐到仙绝之地的凡人居然能研究出如此精妙之物。可惜，只有在这大道残缺之地才能起作用。出了仙绝之地，不过是一堆无用的破铜炼铁罢了。"}]}
execute as @s if score @s jqtime matches 52 as @e[name=寇洪] at @s run replaceitem entity @s slot.weapon.mainhand 0 air
execute as @s if score @s jqtime matches 56 run tellraw @s {"rawtext":[{"text":"[寇洪]：原本我心里还有些许愧疚，现在看来，却是你们自己找死！"}]}
execute as @s if score @s jqtime matches 59 as @e[name=寇洪] run playanimation @s animation.player.swim b
execute as @s if score @s jqtime matches 59 run camera @s fade time 1 0 0.5 color 255 0 0 
execute as @s if score @s jqtime matches 60 run camerashake add @s 4 2 
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s run tp @s ~~~ facing @e[name=寇洪,c=1]
execute as @s if score @s jqtime matches 60 run playsound mob.zombie.woodbreak @s ~ ~ ~ 9 7 25
execute as @s if score @s jqtime matches 60 run playsound mob.snowgolem.hurt @a[r=50] ~~~ 1 4
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^2
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^3
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^4
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^5
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^6
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^7
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^8
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^9
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^10
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^11
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^12
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^13
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^14
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^15
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^16
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^17
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^18
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^19
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^20
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^21
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^22
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^23
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^24
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^25
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^26
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^27
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^28
execute as @s if score @s jqtime matches 60 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^29
execute as @s if score @s jqtime matches 60 at @e[type=minecraft:zombie_villager] run particle minecraft:breeze_wind_explosion_emitter ~ ~1 ~
execute as @s if score @s jqtime matches 62 run tellraw @s {"rawtext":[{"text":"[寇洪]：这是！！？？"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"[道玄子]：这些暗器用凡人之血浸泡过，是仙凡瘴……"}]}
execute as @s if score @s jqtime matches 69 run tellraw @s {"rawtext":[{"text":"[寇洪]：我们刚到此地，就遭到伏击。而且对方还动用了仙凡瘴，显然是有备而来。难道这些凡人背后，有修仙者指点？"}]}
execute as @s if score @s jqtime matches 74 run tellraw @s {"rawtext":[{"text":"[道玄子]：不管怎样，此地诡异，不宜久留。"}]}
execute as @s if score @s jqtime matches 76 run tellraw @s {"rawtext":[{"text":"[道玄子，寇洪]：走！！！"}]}
execute as @s if score @s jqtime matches 76 run scoreboard players set @e[name=寇洪] wy 2
execute as @s if score @s jqtime matches 78 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 道玄子！寇洪！你们二人今日若是遁走，明日你们得到了一部结丹的功法的消息就会传遍整个修仙界！"}]}
execute as @s if score @s jqtime matches 81 run tellraw @s {"rawtext":[{"text":"[道玄子，寇洪]：怎么可能？得到结丹功法一事明明只有我们两人知晓，怎么会走漏了消息？"}]}
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"ps:二人结伴前往洞府探秘、随后寇洪夺了功法一路逃遁、道玄子穷追不舍，寇洪铤而走险，闯入这仙绝之地谋求一线生机…… 这期间所遇到的人事一幕幕在脑海中依次闪过。"}]}
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^2
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^3
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^4
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^5
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^6
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^7
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^8
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^9
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^10
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^11
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^12
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^13
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^14
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^15
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^16
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^17
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^18
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^19
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^20
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^21
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^22
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^23
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^24
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^25
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^26
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^27
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^28
execute as @s if score @s jqtime matches 90 as @e[name=京城守卫] at @s facing entity @e[tag=wy,type=minecraft:zombie_villager,c=1] eyes run particle minecraft:basic_flame_particle ^^^29
execute as @s if score @s jqtime matches 91 as @e[name=寇洪] at @s run summon ender_crystal ~~~~~ minecraft:crystal_explode
execute as @s if score @s jqtime matches 91 as @e[name=道玄子] at @s run summon ender_crystal ~~~~~ minecraft:crystal_explode
execute as @s if score @s jqtime matches 91 run tellraw @s {"rawtext":[{"text":"[道玄子，寇洪]：啊！！！！！！！！！！！！！！！！！！！"}]}
execute as @s if score @s jqtime matches 92 run scoreboard players set @e[name=道玄子] wy 2
execute as @s if score @s jqtime matches 92 run scoreboard players set @e[name=寇洪] wy 3
execute as @s if score @s jqtime matches 94 as @e[name=寇洪] run playanimation @s animation.cow.setup.v1.0 b 99
execute as @s if score @s jqtime matches 94 as @e[name=道玄子] run playanimation @s animation.humanoid.riding.legs.v1.0 b 99
execute as @s if score @s jqtime matches 95 as @e[name=寇洪] at @s run tp @s ~ 57 ~
execute as @s if score @s jqtime matches 95 as @e[name=道玄子] at @s run tp @s ~ 58 ~ 
execute as @s if score @s jqtime matches 95 run tellraw @s {"rawtext":[{"text":"[士兵]：两位仙师，我们太师有令，你们二人如果束手就擒，可保一条性命！"}]}
execute as @s if score @s jqtime matches 97 run tellraw @s {"rawtext":[{"text":"[寇洪]：走。。（看向道玄子，并把储物袋给他）"}]}
execute as @s if score @s jqtime matches 98 at @e[name=寇洪] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 98 at @e[name=寇洪] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 98 at @e[name=寇洪] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 98 at @e[name=寇洪] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 98 at @e[name=寇洪] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 98 at @e[name=寇洪] run playsound mace.heavy_smash_ground @a ~~~ 1 0.1 10
execute as @s if score @s jqtime matches 99 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 100 run tellraw @s {"rawtext":[{"text":"筑基修士寇洪，凡修道两百零五载，以奇物§a§l【虬龙枝】§r§f成就道基。于仙绝之地，被数千凡人围攻，不慎被仙凡瘴所伤。修为顿失，寿元将近。如今身死道消，还道于天！"}]}
execute as @s if score @s jqtime matches 102 run tellraw @s {"rawtext":[{"text":"[士兵]：仙师，我们太师无意与你们拼个你死我活。你若放弃抵抗，我们太师保证你的生命安全……"}]}
execute as @s if score @s jqtime matches 105 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"] 看来此世尝试捕仙是失败了。没想到仙凡瘴对于修仙者的杀伤力度竟然如此厉害。（心里话）"}]}
execute as @s if score @s jqtime matches 109 run tellraw @s {"rawtext":[{"text":"[道玄子]：你们行事鬼祟，用下作之物伏击我们，到底有什么目的，我兄寇洪，死在你这种人手里，我替他不值！"}]}
execute as @s if score @s jqtime matches 111 run tellraw @s {"rawtext":[{"text":"[道玄子]：我的筑基奇物，也请诸位一观！"}]}
execute as @s if score @s jqtime matches 112 run tellraw @s {"rawtext":[{"text":"[道玄子]：吾之道基，名曰：道玄。"}]}

execute as @s if score @s jqtime matches 112 as @e[name=道玄子] run playanimation @s animation.humanoid.move b 0
execute as @s if score @s jqtime matches 112 run scoreboard players set @e[name=道玄子] wy 3
execute as @s if score @s jqtime matches 112 at @e[name=道玄子] run structure load "1/jiji" ~~30~
execute as @s if score @s jqtime matches 113 run playanimation @e[name=jiji] animation.llama.setup.v1.0 a 9999 "" a 
execute as @s if score @s jqtime matches 113 run playanimation @e[name=jiji] animation.ghast.scale b 9999 "" b
execute as @s if score @s jqtime matches 112 as @e[name=jiji] run scoreboard players set @e[name=jiji] wy 1
execute as @s if score @s jqtime matches 112..116 run camerashake add @s 4 2 
execute as @s if score @s jqtime matches 115 run camera @s fade time 1 3 3 color 255 0 0 
execute as @s if score @s jqtime matches 116 run  replaceitem entity @s slot.weapon.offhand 0 minecraft:totem_of_undying 1 1 {"item_lock":{"mode":"lock_in_slot"}}
execute as @s if score @s jqtime matches 116 run damage @s 100 override
execute as @s if score @s jqtime matches 117 run kill @e[name=道玄子]
execute as @s if score @s jqtime matches 117 run kill @e[name=京城守卫]
execute as @s if score @s jqtime matches 117 at @e[name=jiji] run tp @e[name=jiji] ~ -100 ~
execute as @s if score @s jqtime matches 118 run kill @e[name=jiji]
execute as @s if score @s jqtime matches 120 run tp @s 313 53 198 
execute as @s if score @s jqtime matches 120 run tag @s remove jq9
execute as @s if score @s jqtime matches 121 run tickingarea remove temp
execute as @s if score @s jqtime matches 121 run tag @s add jqa
