execute as @s if score @s jqtime matches 2 run inputpermission set @s movement disabled
execute as @s if score @s jqtime matches 2 run camera @s fade time 2 48 2 color 0 0 0
execute as @s if score @s jqtime matches 4 run tellraw @s {"rawtext":[{"text":"---时间很快就过去了---"}]}

execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"[锚定二年] 在殿试中，殿试上发挥出色，果真如考官所说，位于二甲之列，被赐进士出身"}]}
execute as @s if score @s jqtime matches 13 run tellraw @s {"rawtext":[{"text":"[锚定二年] 你于玄京城中四处走关系，终于得偿所愿，得到了江南温县县令一职"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[锚定三年] 你于家中接上婶婶后上任温县。你开始暗中培养自己的心腹班底。同年，你率领手下于深山中找到了前世记忆中的几处矿产"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"[锚定四年] 你成功制作了一批炸药与火绳枪。手下火枪队初试身手便剿灭收编了附近的一处山贼"}]}
execute as @s if score @s jqtime matches 28 run tellraw @s {"rawtext":[{"text":"[锚定五年] 江南大旱，流民遍地。由于你早早的就兴修水利、建造水车引流，所以你治下温县并未受到大的影响。同年，一伙流民聚众造反，冲击琅琊王府。你率兵及时赶到，救下了琅琊王一家。琅琊王对你十分感激"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[锚定六年] 你升为江淮府知府。同年，你娶了当朝吏部侍郎的女儿为妻。"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"[锚定七年] 江南道突发蝗灾，粮食欠收。只有你治下影响最小。同年，你的妻子为你生下了一个儿子。"}]}
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[锚定八年] 你成功制作出了燧发枪"}]}
execute as @s if score @s jqtime matches 48 run structure load "1/rw/rw6" ~~~
execute as @s if score @s jqtime matches 48 run structure load "1/rw/rw6lw" ~~~
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[锚定十年] 琅琊王妃诞下一子，你准备要送礼物去贺喜。"}]}
execute as @s if score @s jqtime matches 50 run playsound random.levelup @s
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 50 run scoreboard players set @s rwa 6
execute as @s if score @s jqtime matches 50 run tag @s add jqa 