execute as @s if score @s jqtime matches 1 run tp @s 39 57 30
execute as @s if score @s jqtime matches 2 run structure load "1/寇洪" 45 57 30 
execute as @s if score @s jqtime matches 2 run structure load "1/道玄子" 43 57 28
execute as @s if score @s jqtime matches 2 run tp @s ~~~ facing @e[name=寇洪,c=1]
execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"[锚定51年] 地点: 大玄国-玄京城"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"[寇洪]：太衍舟核心阵法已经完全修复，防御法阵与攻击法阵只能做简单修复。闯过仙绝大阵问题不大"}]}
execute as @s if score @s jqtime matches 12 run structure load "1/太衍舟" 43 59 31
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：无妨，只要可以返回修仙界，我自会找到回归太衍宗的方法。"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"[寇洪]：驾驶这太衍舟需要最起码炼气期的神识，不知道友是否需要我等代劳…"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：容我一试。"}]}
execute as @s if score @s jqtime matches 25 run structure load "1/tyz" 41 60 30 
execute as @s if score @s jqtime matches 26 as @e[tag=tyz] run playanimation @s animation.ghast.scale a 999
execute as @s if score @s jqtime matches 26 as @e[tag=tyz] run scoreboard players set @s wy 1
execute as @s if score @s jqtime matches 28 as @e[tag=tyz] run scoreboard players set @s wy 2
execute as @s if score @s jqtime matches 30 as @e[tag=tyz] run playanimation @s animation.ghast.scale a 0
execute as @s if score @s jqtime matches 30 run scoreboard players set @s wy 0
execute as @s if score @s jqtime matches 31 as @e[tag=tyz] at @s run tp @e[tag=tyz] ~~-100~
execute as @s if score @s jqtime matches 31 run kill @e[tag=tyz]

execute as @s if score @s jqtime matches 34 run tellraw @s {"rawtext":[{"text":"[寇洪]：道友果然手段不凡，看来我等是多虑了。"}]}
execute as @s if score @s jqtime matches 38 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：不过些许微末伎俩，不值一提！"}]}
execute as @s if score @s jqtime matches 41 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：难道是历经多世轮回，导致我的神识强化了吗？（心里话）"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：被困千载，如今脱困有望，全凭二位功劳！哈哈哈哈"}]}
execute as @s if score @s jqtime matches 48 run tellraw @s {"rawtext":[{"text":"[道玄子]：如今太衍舟已经修复，不知功法awa..."}]}
execute as @s if score @s jqtime matches 52 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：功法早以叫手下送入道玄子道友卧室中"}]}
execute as @s if score @s jqtime matches 56 run tellraw @s {"rawtext":[{"text":"--一段时间后"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[道玄子]：果真如此！"}]}
execute as @s if score @s jqtime matches 63 run tellraw @s {"rawtext":[{"text":"[寇洪]：我等灵石储备不多，还放置一些作为飞舟燃料，我二人今日就告辞了。"}]}
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"[道玄子]：道友如果闯入绝仙大阵的黑暗层，务必保持匀速行驶"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：此地我族还有若干事务没有处理完毕，不能与两位道友同行了！"}]}
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"[寇洪]：无妨。道友若是出去后，可来丛云山脉中的凌天城寻我。"}]}
execute as @s if score @s jqtime matches 80 as @e[name=寇洪,x=45,y=57,z=30,r=20] at @s run tp @s ~~-100~ 
execute as @s if score @s jqtime matches 80 as @e[name=道玄子,x=45,y=57,z=30,r=20] at @s run tp @s ~~-100~ 
execute as @s if score @s jqtime matches 81 run kill @e[name=寇洪,x=45,y=-43,z=30,r=20]
execute as @s if score @s jqtime matches 81 run kill @e[name=道玄子,x=45,y=-43,z=30,r=20]
execute as @s at @s if score @s jqtime matches 81 run playsound random.levelup @s
execute as @s if score @s jqtime matches 81 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 81 run scoreboard players set @s rwa 22
execute as @s if score @s jqtime matches 82 run tag @s add jqa 


