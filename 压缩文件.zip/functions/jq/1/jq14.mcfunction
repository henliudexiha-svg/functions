execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"-你做出了燧发枪，命令工匠按照图纸生产，并将生产中的难点尽数相告"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-随后，工匠到各地私下里招募能工巧匠，力求研发更先进的枪支。"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"[锚定三年]：你扫平温县附近山脉内的所有山贼，并将其全部拉去挖矿。"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[锚定三年]：同年，你靠着矿区，在深山里兴建了许多作坊，大批量生产工艺品和铁器。同时暗中组织商队，去各地巡游贩卖，积攒资金"}]}
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"[锚定四年]：你暗中寻访，终于找到了康宁帝的替身。正是这替身的存在，导致他上一世的暗杀计划差点失败"}]}
execute as @s if score @s jqtime matches 26 run tellraw @s {"rawtext":[{"text":"[锚定四年]：你亲自训练替身，半年过去，几无破绽。"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[锚定五年]：江南大旱。你命心腹假扮流民，冲击琅琊王府。你率众佯装救援，实则里应外合暗地里直接杀了琅琊王一家。同时让替身出场。"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[锚定五年]：你鸠占鹊巢，暗中掌控了琅琊王府。"}]}
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"[锚定五年]：同时，琅琊王一家被杀、仅琅琊王自身得以保全的消息震惊朝野。皇帝大怒，出兵镇压流民。而你有功，得以升江淮府知府。"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"[锚定五年]：你的势力进一步扩大。不过，这之后你反而谨慎了起来。没有继续朝外扩张，而是低调的攀科技、发展生产力。"}]}
execute as @s if score @s jqtime matches 49 run tellraw @s {"rawtext":[{"text":"[锚定七年]：蝗灾如约而至。你早有防备，江淮府自然没有灾情。他还向朝廷申请开仓放粮，接济灾民。朝廷应允。得此机会，你得到了大批人口。之后这些灾民就在你治下安了家，你的实力也随之爆炸式的增长。"}]}
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"[锚定九年]：琅琊王和首席大学士孙女的婚礼如期举行。当晚，你夜闯洞房，将琅琊王妃吓得半死。得知了你杀了琅琊王、使用替身鸠占鹊巢之后，更是怒斥你为逆贼。你不以为意，反而哈哈大笑，让她将这一骇人听闻的事原原本本地写在信上。"}]}
execute as @s if score @s jqtime matches 62 run tellraw @s {"rawtext":[{"text":"[锚定九年]：你带着这封信，假扮琅琊王信使。。。。。。"}]}
execute as @s at @s if score @s jqtime matches 66 run playsound random.levelup @s
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s at @s if score @s jqtime matches 66 run scoreboard players set @s rwa 10
execute as @s if score @s jqtime matches 67 run tag @s add jqa