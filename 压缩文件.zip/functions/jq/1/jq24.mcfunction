execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"-玄京城，状元楼。"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-一众书生聚在一起，观看近日引起天下震动的那几卷古籍。"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"[书生a] 上善若水，水利万物而不争。妙，妙啊！"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"[书生b] 道生一，一生二，二生三，三生万物。寥寥几字，读之顿觉无穷玄妙，此经真是不凡！"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"[书生a] 依我看，只此三千言，便抵得上我之前所有读过文章！"}]}
execute as @s if score @s jqtime matches 27 run tellraw @s {"rawtext":[{"text":"[书生a] 我亦有此感！"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[书生d] 不不不，在我看来，那卷《易》的精妙程度，还要在《道德》之上。虽然文字晦涩艰深，但是字字珠玑，仿佛包含天地至理。"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[书生b] 正是如此，天行健，君子以自强不息！道出我辈心声！"}]}
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 想不到如此精妙绝伦的文字，竟然深埋于地下数千年而无人得知。每每念及此处，我就痛心疾首！"}]}
execute as @s if score @s jqtime matches 43 run tellraw @s {"rawtext":[{"text":"[众书生]: 是呀！！！"}]}
execute as @s if score @s jqtime matches 47 run tellraw @s {"rawtext":[{"text":"[书生a] 是啊，先师生前最爱读书。若是他能读到此几卷经书，不知又会有多快慰。"}]}
execute as @s if score @s jqtime matches 51 run tellraw @s {"rawtext":[{"text":"[书生a] 过往天下读书人，不能闻此经书，皆是不幸啊！"}]}
execute as @s if score @s jqtime matches 51 run tellraw @s {"rawtext":[{"text":"[史书] 可是，这些经书真是前人所书，因战乱而遗失，只得残卷在古墓中保存？我观《南华》、《论语》，其中人事物，皆无记载于史书之中。"}]}
execute as @s if score @s jqtime matches 56 run tellraw @s {"rawtext":[{"text":"[众书生] （猛地一静）"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[书生a] 定是如此。如此文字，绝无今人伪造可能。现存史书，只得近三千年历史。三千年之前，便基本无详细记载。想来这些经典，便是那时候的产物。"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"[书生b] 我听闻，那访古学派面圣时曾言，上古之时，有百家争鸣，所诞生的经典，真如天上繁星，不可胜数。如今我们所读的这几卷经书，不过是其中微不足道的一部分。"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[众书生] （惊呼）竟有此事！？"}]}
execute as @s if score @s jqtime matches 73 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 一想到还有这么多经典文章深埋地下，不见人间，我就无比心痛、夜不能寐！"}]}
execute as @s if score @s jqtime matches 78 run tellraw @s {"rawtext":[{"text":"[书生b] 知其余经典，又是何等模样。"}]}
execute as @s if score @s jqtime matches 81 run tellraw @s {"rawtext":[{"text":"[史书] 可毕竟这些古籍是深藏于各个古墓之中。访古学派所言大肆发掘古墓，寻找遗失经典一事，实在有违人伦。"}]}
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"-众书生本能的想出声附和，但是一想到那无数经典文章还待在地下等待发掘，他们的语气就变得不再那么坚决了。"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"[书生c] 那访古学派领袖不是说了么，他们行的是保护之事，抢救性发掘。不是行破坏之举。"}]}
execute as @s if score @s jqtime matches 95 run tellraw @s {"rawtext":[{"text":"[书生a] 不错，我听闻他们每发掘一处古墓，不似以往盗墓贼一般大肆破坏，只取金银。而是小心将其中物件尽数取出，一一妥善保存。若有损坏，还有专人负责修复。"}]}
execute as @s if score @s jqtime matches 100 run tellraw @s {"rawtext":[{"text":"[书生b] 的确，不能简单的将其和盗墓贼相提并论。"}]}
execute as @s if score @s jqtime matches 103 run tellraw @s {"rawtext":[{"text":"-时间很快就过去了"}]}
execute as @s if score @s jqtime matches 107 run tellraw @s {"rawtext":[{"text":"你认为火候差不多了，你在暗中谋求天下的同时，李凡也在逐步推进访古学派在世俗间的影响程度。"}]}
execute as @s if score @s jqtime matches 107 run tellraw @s {"rawtext":[{"text":"你觉得是时候给皇帝暗中下慢性毒药。"}]}
execute as @s at @s if score @s jqtime matches 110 run playsound random.levelup @s
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 110 run scoreboard players set @s rwa 17
execute as @s if score @s jqtime matches 111 run tag @s add jqa 