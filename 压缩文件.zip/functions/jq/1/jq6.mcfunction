execute as @s  if score @s jqtime matches 1 run inputpermission set @s movement disabled
execute as @s  if score @s jqtime matches 1 run structure load "1/czdd" 116 61 259
execute as @s  if score @s jqtime matches 1 run effect @e[name="村长的弟弟"] slowness 30 100 true 
execute as @s if score @s jqtime matches 4 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 刚从我家田地里出来吧？"}]}
execute as @s if score @s jqtime matches 9 run tellraw @s {"rawtext":[{"text":"[村长弟弟]: 哟，消息还挺灵通的嘛，怎么？10个货币买你家田地，划算吧？"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[村长弟弟]: 只不过，你家的老太婆不识趣，不过看到你都跑到这里来了，卖给我，我就既往不咎"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 你还真说的出口，10个货币买？好大的口气呀！"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"[村长弟弟]: 哼，既然如此，那就别怪我不客气了！"}]}
execute as @s if score @s jqtime matches 21 run effect @e[name="村长的弟弟"] slowness 0 200 true
execute as @s if score @s jqtime matches 30 run tag @s add jqa