execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[心腹] 要我偷偷下药，把皇帝毒杀？"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 这毒药无色无味，像水一样，你要小心谨慎，一定不要被发现"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[心腹] 明白"}]}
execute as @s if score @s jqtime matches 17 run tellraw @s {"rawtext":[{"text":"[锚定六年] 由于你的决定，心腹下药的虽然没有被发现，但是皇帝正年轻力壮，却忽的身体一天不如一天，居然变得有些疑神疑鬼。"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"[锚定六年] 皇帝怀疑有人暗中加害他。而首席怀疑对象，就是原本与你最要好的兄弟，琅琊王。"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[锚定七年] 皇帝病危之时，他没有将皇位传给琅琊王，反而传给了向来有些玩世不恭的汝南王。"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"[锚定七年] 同时，你安插在宫中的内应及时传出消息，你闻讯后立刻行动。"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[锚定七年] 你立即派手下前往汝南王进京的道路上进行暗杀"}]}
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"[锚定七年] 并且以琅琊王的名义，宣称皇帝被身边奸人所害，打着“靖国难”的旗号，带着这些年来组建的军队，一路急行军，在所有人反应过来之前，攻进了京城，以武力占据了朝庭。"}]}
execute as @s if score @s jqtime matches 41 run tellraw @s {"rawtext":[{"text":"[锚定七年] 自然朝中诸位大臣不服。皇帝遗诏，传位汝南王。你琅琊王这么做，不是造反么？"}]}
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[锚定七年] 虽然诸位大臣虽然明面上摄于李凡的武力压迫，不能公开反抗。但是阳奉阴违，消极罢工还是做得到的。"}]}
execute as @s if score @s jqtime matches 49 run tellraw @s {"rawtext":[{"text":"[锚定七年] 有的大臣暗中联络各地藩王，试图让其率兵进京，行“拨乱反正”之举。你自是没有心软，狠狠杀了一批人才勉强震慑住。"}]}
execute as @s if score @s jqtime matches 53 run tellraw @s {"rawtext":[{"text":"[锚定七年] 和上一世一样，首席大学士暗中相助，经过了几个月的时间，才堪堪稳定住局势。"}]}
execute as @s if score @s jqtime matches 57 run tellraw @s {"rawtext":[{"text":"[锚定22年] 内忧外患彻底解决，比上一世晚六年，你深深感到差之毫厘，谬以千里。"}]}
execute as @s if score @s jqtime matches 72 run tellraw @s {"rawtext":[{"text":"[锚定35年] 即将到上一世访仙营说的“十五年会散开半日”的日子了"}]}
execute as @s at @s if score @s jqtime matches 79 run playsound random.levelup @s
execute as @s if score @s jqtime matches 79 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 79 run scoreboard players set @s rwa 13
execute as @s if score @s jqtime matches 80 run tag @s add jqa 