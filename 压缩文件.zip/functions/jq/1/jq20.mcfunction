execute as @s if score @s jqtime matches 1 run camera @s fade time 2 8 2 color 0 0 0
execute as @s if score @s jqtime matches 3 run tp @s 142 74 104
execute as @s if score @s jqtime matches 1 run tag @s add jq9
execute as @s if score @s jqtime matches 1 run kill @e[name=京城守卫] 
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 87
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 90
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 137 75 95
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 87
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 90
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 148 75 95
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 145 75 105
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 140 75 105
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 112
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 1
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 122
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 146 59 127
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 112
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 1
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 122
execute as @s if score @s jqtime matches 1 run structure load "1/jcsw" 138 59 127
execute as @s if score @s jqtime matches 1..34 run tag @e[name=京城守卫] add wy 
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[锚定50年] 地点: 大玄国-玄京-太师府"}]}
execute as @s if score @s jqtime matches 9.. as @e[name=京城守卫] at @s run tp @s ~~~ facing @p 
execute as @s if score @s jqtime matches 9 run tickingarea add 0 59 315 41 58 264 temp 
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-往日无比热闹的玄京城如今寂静地有些诡异。"}]}
execute as @s if score @s jqtime matches 19 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 20 run structure load "1/道玄子" 0 86 315
execute as @s if score @s jqtime matches 20 run structure load "1/寇洪" 11 86 305
execute as @s if score @s jqtime matches 20..28 as @e[name=道玄子] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20..28 as @e[name=寇洪] at @s facing 146 74 106 run tp @s ~~~ ~ 0
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=道玄子] wy 1
execute as @s if score @s jqtime matches 20 run scoreboard players set @e[name=寇洪] wy 1
execute as @s if score @s jqtime matches 22 run tag @e[name=道玄子] add wy2
execute as @s if score @s jqtime matches 22 run tag @e[name=寇洪] add wy2
execute as @s if score @s jqtime matches 21..27 at @e[name=道玄子] run camera @s set minecraft:free ease 1 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 at @e[name=道玄子] run camera @s set minecraft:free ease 0.7 linear pos ^2^^-5 facing @s
execute as @s if score @s jqtime matches 22..27 run tp @s 142 74 104

execute as @s if score @s jqtime matches 28 at @s anchored eyes run camera @s set minecraft:free ease 1 linear pos ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28 at @s run tp @s ~~~ facing @e[name=道玄子] 
execute as @s if score @s jqtime matches 29 run camera @s clear
execute as @s if score @s jqtime matches 28.. as @e[name=寇洪] at @s run tp @s ~~~ facing @e[name=道玄子]
execute as @s if score @s jqtime matches 28.. as @e[name=道玄子] at @s run tp @s ~~~ facing @e[name=寇洪]
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[寇洪]：道玄子！！！你不要欺人太甚！！！"}]}
execute as @s if score @s jqtime matches 36 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 寇洪小儿，吾等奉道玄子仙师之命，在此恭候多时了！"}]}
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s run tp @s ~~~ facing @e[name=寇洪,c=1]
execute as @s if score @s jqtime matches 37..38 run playsound mob.zombie.woodbreak @s ~ ~ ~ 9 7 25
execute as @s if score @s jqtime matches 37..38 run playsound mob.snowgolem.hurt @a[r=50] ~~~ 1 4
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^2
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^3
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^4
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^5
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^6
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^7
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^8
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^9
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^10
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^11
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^12
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^13
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^14
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^15
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^16
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^17
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^18
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^19
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^20
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^21
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^22
execute as @s if score @s jqtime matches 37..38 as @e[name=京城守卫] at @s facing entity @e[name=寇洪] eyes run particle minecraft:basic_flame_particle ^^^23
execute as @s if score @s jqtime matches 37..38 at @e[name=寇洪] run particle minecraft:breeze_wind_explosion_emitter ~ ~1 ~
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"[寇洪]：怎么可能？道玄子怎会知道我会逃往这里？(心里话)"}]}
execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"[寇洪]：仙凡瘴！？道玄子，你好生卑鄙！"}]}
execute as @s if score @s jqtime matches 42..44 at @e[name=寇洪] run particle minecraft:mobflame_single ~ ~2 ~
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[道玄子]：这些凡人，怎么打着我的旗号袭击寇洪？，居然还会使用仙凡瘴？！！（心里话）"}]}
execute as @s if score @s jqtime matches 48 run tellraw @s {"rawtext":[{"text":"[道玄子]：此处有些诡异！寇洪，这些凡人并不是我指使的！"}]}
execute as @s if score @s jqtime matches 52 run tellraw @s {"rawtext":[{"text":"[寇洪]：没有修仙者指使，这些凡人怎会知道，用仙凡瘴对付我！！！"}]}
execute as @s if score @s jqtime matches 56 run tellraw @s {"rawtext":[{"text":"[道玄子]：相识百年，你何时见过我说过谎话？此处确实不是……"}]}
execute as @s if score @s jqtime matches 58 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）:道玄子仙师如何翻脸不认人了？不是说好只要我等协助你，夺了他的结丹功法，就会带领我的族人离开这仙绝之地么？"}]}
execute as @s if score @s jqtime matches 60..63 at @e[name=寇洪] run particle minecraft:mobflame_single ~ ~2 ~
execute as @s if score @s jqtime matches 62 run tellraw @s {"rawtext":[{"text":"[寇洪]：还说不是你！除了你我，这世间还会有谁功法一事！"}]}
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"[道玄子]：此人居然知晓结丹功法一事，真是服了这个老六（心彻底沉了下去）[心里话]"}]}
execute as @s if score @s jqtime matches 69 run tellraw @s {"rawtext":[{"text":"[道玄子]：你这鬼祟得无耻小人，莫在这里信口雌黄"}]}
execute as @s if score @s jqtime matches 69 as @e[name=道玄子] at @s run tp @s ~~~ facing  @e[c=1,name=京城守卫]
execute as @s if score @s jqtime matches 70 as @e[name=寇洪] run playanimation @s animation.humanoid.brushing b
execute as @s if score @s jqtime matches 70 as @e[name=道玄子] at @s run scoreboard players set @e[c=3,name=京城守卫] wy 3
execute as @s if score @s jqtime matches 74 as @e[name=道玄子] at @s run scoreboard players set @e[c=1,scores={wy=3},name=京城守卫] wy 4
execute as @s if score @s jqtime matches 74 as @e[name=道玄子] at @s run scoreboard players set @e[c=1,scores={wy=3},name=京城守卫] wy 5
execute as @s if score @s jqtime matches 74 as @e[name=道玄子] at @s run scoreboard players set @e[c=1,scores={wy=3},name=京城守卫] wy 6
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）:难道仙师现在就欲杀人灭口了么？"}]}
execute as @s if score @s jqtime matches 76..78 at @e[name=道玄子] run particle minecraft:mobflame_single ~ ~2 ~
execute as @s if score @s jqtime matches 79 run tellraw @s {"rawtext":[{"text":"[寇洪]：道玄子！你我结识百年，不想我却是看错了你！你若是想要结丹功法，何必使这些下作手段。"}]}
execute as @s if score @s jqtime matches 82 run tellraw @s {"rawtext":[{"text":"[寇洪]：我也不跑了，你有本事尽管来取！"}]}
execute as @s if score @s jqtime matches 83 as @e[name=寇洪] run playanimation @s animation.player.swim b
execute as @s if score @s jqtime matches 84 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^2
execute as @s if score @s jqtime matches 84 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^4
execute as @s if score @s jqtime matches 84 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^6
execute as @s if score @s jqtime matches 84 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^8
execute as @s if score @s jqtime matches 84 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^10
execute as @s if score @s jqtime matches 84 run camerashake add @s 2.5 1 
execute as @s if score @s jqtime matches 84 at @e[name=道玄子] run particle minecraft:breeze_wind_explosion_emitter ~ ~1 ~
execute as @s if score @s jqtime matches 86 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 道玄子此人反复不定、睚眦必报，若他获胜。。。。。"}]}
execute as @s if score @s jqtime matches 88 run tellraw @s {"rawtext":[{"text":"[道玄子]：无耻小人，给我住口"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 我等断无活路。儿郎们听令，帮助寇洪仙师对付道玄子！"}]}
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^2
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^3
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^4
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^5
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^6
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^7
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^8
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^9
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^10
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^11
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^12
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^13
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^14
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^15
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^16
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^17
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^18
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^19
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^20
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^21
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^22
execute as @s if score @s jqtime matches 88 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^23
execute as @s if score @s jqtime matches 37..38 at @e[name=道玄子] run particle minecraft:breeze_wind_explosion_emitter ~ ~1 ~
execute as @s if score @s jqtime matches 94 run tellraw @s {"rawtext":[{"text":"[寇洪]：正所谓多行不义必自毙，想不到你也有今天。（得意）"}]}
execute as @s if score @s jqtime matches 97 run tellraw @s {"rawtext":[{"text":"[道玄子]：你这蠢货！"}]}
execute as @s if score @s jqtime matches 100 run tellraw @s {"rawtext":[{"text":"[寇洪]：好啊！你终于把心里话说出来了！"}]}
execute as @s if score @s jqtime matches 104 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]（扬声器扩大版）: 寇洪仙师，我等助你一臂之力！"}]}

execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^1
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^2
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^3
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^4
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^5
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^6
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^7
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^8
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^9
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^10
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^11
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^12
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^13
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^14
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^15
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^16
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^17
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^18
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^19
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^20
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^21
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^22
execute as @s if score @s jqtime matches 108 as @e[name=京城守卫] at @s facing entity @e[name=道玄子] eyes run particle minecraft:basic_flame_particle ^^^23
execute as @s if score @s jqtime matches 109 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^2
execute as @s if score @s jqtime matches 109 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^4
execute as @s if score @s jqtime matches 109 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^6
execute as @s if score @s jqtime matches 109 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^8
execute as @s if score @s jqtime matches 109 as @e[name=寇洪] at @s anchored eyes facing entity @e[name=道玄子] eyes run particle minecraft:sonic_explosion ^^^10
execute as @s if score @s jqtime matches 109 as @e[name=道玄子] at @s run summon ender_crystal ~~~~~ minecraft:crystal_explode
execute as @s if score @s jqtime matches 109 run camerashake add @s 4 2
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"[道玄子]：你！！。。。"}]}
execute as @s if score @s jqtime matches 110 at @e[name=道玄子] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 110 at @e[name=道玄子] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 110 at @e[name=道玄子] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 110 at @e[name=道玄子] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 110 at @e[name=道玄子] run summon minecraft:lightning_bolt ~~3~
execute as @s if score @s jqtime matches 111 run kill @e[name=道玄子]
execute as @s if score @s jqtime matches 111 run tellraw @s {"rawtext":[{"text":"筑基修士道玄子，凡修道两百零一载，以奇物§a§l【锈剑道玄】§r§f成就道基。在仙绝之地，与人拼杀，最终死于筑基修士寇洪之手。　如今身死道消，还道于天！"}]}
execute as @s if score @s jqtime matches 114 as @e[name=寇洪] at @s run tp @s ~~~ facing @p[scores={jqa=20,jq=..19}] 
execute as @s if score @s jqtime matches 118 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 老夫"},{"selector":"@s"},{"text":"，见过仙师 "}]}
execute as @s if score @s jqtime matches 120 run tellraw @s {"rawtext":[{"text":"[寇洪]：哼"}]}
execute as @s if score @s jqtime matches 123 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 还请仙师慈悲，救我族上下千余口人性命"}]}
execute as @s if score @s jqtime matches 124 as @e[name=寇洪] run scoreboard players set @s wy 4
execute as @s if score @s jqtime matches 127 run tellraw @s {"rawtext":[{"text":"[寇洪]：你区区一介凡人，也敢插手我们修仙者之间得战斗"}]}
execute as @s if score @s jqtime matches 130 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不过是求一线生机罢了！"}]}
execute as @s if score @s jqtime matches 133 run tellraw @s {"rawtext":[{"text":"[寇洪]：好个求一线生机！"}]}
execute as @s if score @s jqtime matches 135 run tellraw @s {"rawtext":[{"text":"[寇洪]：世道艰难，谁又不是为了那一线生机而苦苦挣扎呢。"}]}
execute as @s if score @s jqtime matches 138 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 道玄子..仙师仙师曾许诺于我。。。。。"}]}
execute as @s if score @s jqtime matches 140 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 不知仙师。。"}]}
execute as @s if score @s jqtime matches 144 run tellraw @s {"rawtext":[{"text":"[寇洪]：那绝仙大阵凶险无比，之前我二人闯进来，也有运气得成分，如今我自己离开，都要费一番功夫，又怎么可能带凡人离开"}]}
execute as @s if score @s jqtime matches 149 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 什。。么。。。。。？？？？？"}]}
execute as @s if score @s jqtime matches 151 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 连你们也不知道，离开此地的方法？唉，此地不是说话的地方，仙师还请随我来"}]}
execute as @s if score @s jqtime matches 151 run camera @s fade time 2 4 4 color 0 0 0 
execute as @s if score @s jqtime matches 156 run tp @s 178 60 195
execute as @s if score @s jqtime matches 154 as @e[name=京城守卫] at @s run tp @s ~~-100~ 
execute as @s if score @s jqtime matches 155 run kill @e[name=京城守卫]
execute as @s if score @s jqtime matches 154 as @e[name=寇洪] at @s run tp @s ~~-100~ 
execute as @s if score @s jqtime matches 155 run kill @e[name=寇洪]
execute as @s if score @s jqtime matches 155 run tag @s remove jq9
execute as @s if score @s jqtime matches 155 run tickingarea remove temp
execute as @s if score @s jqtime matches 157 run tag @s add jqa
