execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 哼，我记得上一世连考10年没上榜，这人态度也是越来越恶劣"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 还得半年才开始科举会试，趁这个时候，得做把好用的武器，进而发展火器"}]}
execute as @s if score @s jqtime matches 12 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]: 我还记得上一世村长的弟弟觊觎我家祖传的肥沃田地，暗中逼迫。婶婶勉励抗拒但是力有不逮。这次我要略施小计就摆平了此事"}]}
execute as @s if score @s jqtime matches 14 run scoreboard players set @s rwa 2 
execute as @s if score @s jqtime matches 14 run playsound random.levelup @s 
execute as @s at @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 17 run tag @s add jqa