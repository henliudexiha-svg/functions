execute as @s if score @s jqtime matches 1 run camera @s fade time 1 2 1 color 0 0 0
execute as @s if score @s jqtime matches 2 run tp @s 4018 -1 1923 -70 0
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"---你突破成功，一丝丝天地灵气流入你的体内，你感觉浑身舒畅无比"}]}
execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"---灵气在体内翻腾运转，润物无声般改善着你已经略显苍老的身躯。"}]}
execute as @s if score @s jqtime matches 12 run tellraw @s {"rawtext":[{"text":"---你感觉自己又年轻了许多，整个人都充满了活力"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"-你出门后，见到张浩波正等在门外"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"[张浩波]: 仙师！恭喜恭喜！"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"[张浩波]: 看你造成的动静，一看就是你突破了炼气期，真是可喜可贺！"}]}
execute as @s if score @s jqtime matches 27 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 说起来好几年都没变了，最近过的怎么样？"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[张浩波]: 托您的福，船队这几年的效益着实不错。尤其是您每次出海都能捞回大量财宝的事，一直吸引着大量的年轻人想要加入船队。"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[张浩波]: 不过……沧远号上的兄弟们，最近商量着要离开琉璃岛。我也隐隐有这个想法。"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 既然日子过得不错，怎么会突然生出了离开的念头？"}]}
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[张浩波]: 不瞒您，最近出海，遇到了种种奇怪的事情。比如从云海的水位异常下降，水里的鱼也像逃难似的全聚在一起"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[张浩波]: 更不寻常的是，过去三年里，整个从云海，居然没有发生过一场风灾"}]}
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 没有风灾不是好事吗？"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[张浩波]: 自我从出生起，这从云海年年都有大大小小的风灾，如今却是整整三年未见风灾，实在太过反常"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 岛上有护岛大阵庇佑，更有何仙师坐镇。就算有什么状况，想来也能应对。"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[张浩波]: 您说的肯定没问题，船上兄弟也有不少人是这么想的。可我就是隐隐感到不安，怎么也放不下心来。 "}]}
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 背井离乡不是易事，还要再三思虑才是。"}]}
execute as @s if score @s jqtime matches 80 run camera @s fade time 1 13 1 color 0 0 0
execute as @s if score @s jqtime matches 85 run tellraw @s {"rawtext":[{"text":"---没过几分钟，何正浩便飞了过来"}]}
execute as @s if score @s jqtime matches 88 run tellraw @s {"rawtext":[{"text":"[何正浩]: 我刚刚察觉岛内灵力有所异动，就知道应该是你突破了"}]}
execute as @s if score @s jqtime matches 82 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 还要多谢前辈指引"}]}
execute as @s if score @s jqtime matches 86 run tellraw @s {"rawtext":[{"text":"[何正浩]: 举手之劳罢了，我来找你，想带你去万仙岛？"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 正有此意，可随时动身。"}]}
execute as @s if score @s jqtime matches 93 run tp @s 3449 94 2393 180 0
execute as @s if score @s jqtime matches 97 run tellraw @s {"rawtext":[{"text":"[何正浩]: 这里是从云海万仙岛驻地，劝你没事还是不要乱飞的好。整个丛云海的修士都聚集在这里，其中不乏金丹、元婴境的强者。若是你飞在他们头顶，惹到了他们，说不定便会被其记在心上。"}]}
execute as @s if score @s jqtime matches 105 run tellraw @s {"rawtext":[{"text":"[何正浩]: 前面这镜子就是我们万仙盟的天玄镜了。"}]}
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"[何正浩]: 传说这天玄镜在仙尊授道时，映照了仙尊法影，诞生了一丝意志，最终衍化成如今的天地灵宝，现在万仙盟中的大部分事务，都是由这天玄镜处理"}]}
execute as @s if score @s jqtime matches 115 run tellraw @s {"rawtext":[{"text":"[何正浩]: 我再和你确认一下，要加入我们万仙盟吗？"}]}
execute as @s if score @s jqtime matches 118 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 心向仙盟，加入是我的荣耀"}]}
execute as @s if score @s jqtime matches 121 run camera @s set minecraft:free ease 2 linear pos 3449 97 2368 rot 0 180
execute as @s if score @s jqtime matches 123 run tellraw @s {"rawtext":[{"text":"[天玄镜]: 引荐一炼气初期修士，记中等丁功，折算五十灵石，当先灵石：920"}]}
execute as @s if score @s jqtime matches 128 run tellraw @s {"rawtext":[{"text":"[何正浩]: 小友有什么问题，尽管问天玄镜，我还有守岛职务在身，就不多陪了"}]}
execute as @s if score @s jqtime matches 134 run tellraw @s {"rawtext":[{"text":"[天玄镜]: 修士"},{"selector":"@s"},{"text":" 欢迎加入万仙盟，作为福利，你获得20灵石，可兑换实体灵石，功法，法宝等"}]}
execute as @s if score @s jqtime matches 135 run scoreboard players add @s lsa 20
execute as @s if score @s jqtime matches 135 run clear @s gold:hz_1
execute as @s if score @s jqtime matches 135 run give @s gold:hz_2 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
execute as @s if score @s jqtime matches 138 run tellraw @s {"rawtext":[{"text":"[天玄镜]: 你可通过修士交易，完成任务等方式获得灵石"}]}
execute as @s if score @s jqtime matches 140 run title @s title "还真已升级"
execute as @s at @s if score @s jqtime matches 140 run playsound random.levelup @s
execute as @s if score @s jqtime matches 142 run camera @s clear
execute as @s if score @s jqtime matches 145 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"] :（看了看商店）这最简单的练气期功法也都要700多灵石，而练气初期能接取的普通任务也就几十灵石"}]}
execute as @s if score @s jqtime matches 150 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"] :（叹了口气）真是牛马修仙啊！！"}]}
execute as @s if score @s jqtime matches 155 run tellraw @s {"rawtext":[{"text":"---你有新的影像留言，请及时查收"}]}
execute as @s if score @s jqtime matches 155 run playsound place.amethyst_cluster @s
execute as @s if score @s jqtime matches 158 run tellraw @s {"rawtext":[{"text":"萧恒---你终于来了"}]}
execute as @s if score @s jqtime matches 162 run tellraw @s {"rawtext":[{"text":"萧恒---在琉璃岛是，就承蒙你的照顾，当日不辞而别，心中愧疚不以"}]}
execute as @s if score @s jqtime matches 166 run tellraw @s {"rawtext":[{"text":"萧恒---一年前刚刚突破到炼气后期，为突破瓶颈，我欲前往丛云海中央，云水天宫遗迹，寻找天地奇物，成就道基"}]}
execute as @s if score @s jqtime matches 170 run tellraw @s {"rawtext":[{"text":"萧恒---临走前我为你留下了一门水属性功法，"},{"selector":"@s"},{"text":"大哥你切记好好修炼"}]}
execute as @s if score @s jqtime matches 171 run structure load "gf/lq/小衍水决" ~~~
execute as @s if score @s jqtime matches 174 run tellraw @s {"rawtext":[{"text":"萧恒---等我回来后，必定要和李大哥你痛饮一番！"}]}
execute as @s if score @s jqtime matches 178 run tellraw @s {"rawtext":[{"text":"---影像留言结束"}]}

execute as @s if score @s jqtime matches 180 run tag @s add jqa