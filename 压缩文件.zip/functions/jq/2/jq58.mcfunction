execute as @s if score @s jqtime matches 1 run playsound place.amethyst_cluster @s
execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"[还真]: 发现可充能物品，是否进行充能。"}]}
execute as @s if score @s jqtime matches 2 run tellraw @s {"rawtext":[{"text":"[还真]: 天地奇物：沧海珠（初）"}]}
execute as @s if score @s jqtime matches 3 run structure load "2/qw/cchz" 3719 51 1837
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 这里还可以遇到这个？？？"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"[赵管事]： 我就要这几个了"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 我也选好了"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"--二人选好物品之后，各自商业互吹了一会"}]}
execute as @s if score @s jqtime matches 18 run camera @s fade time 2 20 1 color 0 0 0
execute as @s if score @s jqtime matches 20 run tp @s 3615 -1 1958
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"-这几月你天天捕捞鱼，置换灵石"}]}
execute as @s if score @s jqtime matches 28 run scoreboard players add @s lsa 100

execute as @s at @s if score @s jqtime matches 40 run playsound random.levelup @s
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 40 run scoreboard players set @s rwa 31
execute as @s if score @s jqtime matches 41 run tag @s add jqa