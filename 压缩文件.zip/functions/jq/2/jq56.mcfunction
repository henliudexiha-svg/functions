execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"-今天你出海了"}]}
execute as @s if score @s jqtime matches 4 run tellraw @s {"rawtext":[{"text":"-但是所有人都对你客客气气"}]}
execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"-不出意外的，你们发现了”财宝“"}]}
execute as @s if score @s jqtime matches 9 run scoreboard players add @s lsa 5
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"[张浩波]：赶紧叫天宝楼的赵管事，赶紧！"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"[张浩波]：确定了，确定了"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[赵管事]：通灵宝体呀……"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"[张浩波]：不过这次比上次少了点。。。"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[赵管事]：那也是因有之理。哪能每次都有如此运气。"}]}
execute as @s if score @s jqtime matches 38 run tellraw @s {"rawtext":[{"text":"[赵管事]：听说，你苦心积虑，乃是为了求得净体灵池的一个名额？"}]}
execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：正是如此。我遭遇大变，方才明白，世间的荣华富贵皆是过眼云烟。就算有用之不尽的财宝，百年后也要化作一抔黄土。唯有寻仙问道，得证长生，方才不枉来这世间一遭！"}]}
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"[赵管事]：你如此年纪，还能有向仙之心，我不如你！"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：谬赞了！不知赵管事对这净体灵池名额一事……"}]}
execute as @s if score @s jqtime matches 54 run tellraw @s {"rawtext":[{"text":"[赵管事]：此事我帮不了你，由仙师主持，不仅要得到仙师的认可，还要100灵石"}]}
execute as @s if score @s jqtime matches 58 run tellraw @s {"rawtext":[{"text":"[赵管事]：不过你也不用担心，能比过天宝楼的也没有几家"}]}
execute as @s if score @s jqtime matches 62 run tellraw @s {"rawtext":[{"text":"[赵管事]：不过从仙师公布的所缺名单来看，不知这星海流沙是何物？"}]}
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"-过了几日"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"-这琉璃岛表面还是风平浪静，实则早已暗流涌动，你在岛上暗中打探无果"}]}
execute as @s if score @s jqtime matches 70 run camera @s fade time 2 75 3 color 0 0 0
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"-不过这天，却迎来了一位意料之外的客人。"}]}
execute as @s if score @s jqtime matches 80 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：不知小兄弟找我有何事？"}]}
execute as @s if score @s jqtime matches 84 run tellraw @s {"rawtext":[{"text":"[萧恒]：听说李老哥最近也在寻找星海流沙？"}]}
execute as @s if score @s jqtime matches 87 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：你知道这东西？？？？？"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"[萧恒]：是的，当初仙师降临大离，许诺只要凑齐他所需要的物资，就能带一批人前往修仙大世界，分到我家所需搜集的，就是这星海流沙。"}]}
execute as @s if score @s jqtime matches 95 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：说吧，你的条件是什么？"}]}
execute as @s if score @s jqtime matches 99 run tellraw @s {"rawtext":[{"text":"[萧恒]：当初你出钱安葬了长玉，也算是对我有恩，这消息本应直接告诉你，但我没有老哥你这么大的本事，如今还住在贫民窟里，每天都要干苦力维持生活……"}]}
execute as @s if score @s jqtime matches 104 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：此物我志在必得，只要你能提供线索，有什么要求尽管提"}]}
execute as @s if score @s jqtime matches 108 run tellraw @s {"rawtext":[{"text":"[萧恒]：如此我就先谢谢老哥了。此物说来并不稀有，只是仙师的称呼与我们凡人不同而已。当然，所谓的星海流沙，就是天上的陨铁而已。"}]}
execute as @s if score @s jqtime matches 112 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：星海流沙……原来如此。只要是陨铁就行了么？"}]}
execute as @s if score @s jqtime matches 116 run tellraw @s {"rawtext":[{"text":"[萧恒]：首先，这陨铁外观要好，表面坑坑洼洼的就不行。其次，一块的整体重量最少要在五十斤以上。然后……"}]}
execute as @s if score @s jqtime matches 120 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：说吧，你想要些什么。"}]}
execute as @s if score @s jqtime matches 125 run tellraw @s {"rawtext":[{"text":"[萧恒]：我只想要个像样点的院子，外加一份稍微轻松点的工作就行。当然，若是能有几名侍女就更好了。（小声）"}]}
execute as @s if score @s jqtime matches 130 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：堂堂镇南王之子，就这么点要求？（奇怪）"}]}
execute as @s if score @s jqtime matches 135 run tellraw @s {"rawtext":[{"text":"[萧恒]：我清楚我自己的能耐。若是突然有了让人眼红的财富，反而容易招来灾祸。"}]}
execute as @s if score @s jqtime matches 140 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：千难万苦来到这修仙大世界，就没有修仙的打算？"}]}
execute as @s if score @s jqtime matches 145 run tellraw @s {"rawtext":[{"text":"[萧恒]：日后再说吧，对修仙实在提不起兴趣，那《玄黄清心咒》一读就昏昏欲睡"}]}
execute as @s if score @s jqtime matches 149 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：......."}]}
execute as @s if score @s jqtime matches 152 run tellraw @s {"rawtext":[{"text":"-来到了天宝楼"}]}
execute as @s if score @s jqtime matches 155 run tellraw @s {"rawtext":[{"text":"[赵管事]：星铁流沙就是陨铁？那萧恒的可信么？"}]}
execute as @s if score @s jqtime matches 160 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：应该没有说谎，但也不能不印证"}]}
execute as @s if score @s jqtime matches 164 run tellraw @s {"rawtext":[{"text":"[赵管事]：万华商会的商会行走因该马上会路过丛云海，倒时候我可以联系上他。"}]}
execute as @s at @s if score @s jqtime matches 167 run playsound random.levelup @s
execute as @s if score @s jqtime matches 167 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 167 run scoreboard players set @s rwa 30
execute as @s if score @s jqtime matches 168 run tag @s add jqa


