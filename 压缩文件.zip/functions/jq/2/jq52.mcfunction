execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"[船员a]：大家不要怕，已经发讯号给仙师了！"}]}
execute as @s if score @s jqtime matches 6 run tellraw @s {"rawtext":[{"text":"[船员a]：他很快就会赶来救我门了"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：趁乱先混进本地人群准没错"}]}
execute as @s if score @s jqtime matches 13 run structure load "神秘人" 3860 30 2085
execute as @s if score @s jqtime matches 13 run camera @s set minecraft:free ease 2 linear pos 3859 31 2089 facing @s 
execute as @s if score @s jqtime matches 15 run scoreboard players set @s wy 1
execute as @s if score @s jqtime matches 15 run camera @s set minecraft:free ease 4 linear pos ~~30~ facing @s
execute as @s if score @s jqtime matches 19 run camera @s set minecraft:free ease 1 linear pos ~~1.8~ rot ~~
execute as @s if score @s jqtime matches 20 run camera @s clear 
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"[神秘人]：谁给我发的信号？"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"[苏长玉]：小人苏长玉，请仙师出手相救！"}]}
execute as @s if score @s jqtime matches 29 run tellraw @s {"rawtext":[{"text":"[神秘人]：规矩你们懂吧？到了地方之后，会有专人带你们去补办身份，一切就跟我没关系了"}]}
execute as @s if score @s jqtime matches 33 run tellraw @s {"rawtext":[{"text":"[苏长玉]：小人明白。家中长辈都已经交代过了"}]}
execute as @s if score @s jqtime matches 35 as @e[name=神秘人] at @s run playanimation @s animation.player.swim b
execute as @s if score @s jqtime matches 35 run camera @s fade time 1 2 0.5 color 0 0 0 

execute as @s if score @s jqtime matches 36 run kill @e[name=神秘人,scores={wy=1}]

execute as @s if score @s jqtime matches 42 run tellraw @s {"rawtext":[{"text":"[肖恒]：求什么道，修什么仙,我爹要把我送来这大世界，要我说,修仙哪有勾栏听曲快活。"}]}
execute as @s if score @s jqtime matches 46 run tellraw @s {"rawtext":[{"text":"[苏长玉]：事到如今，还说这些话做什么？与其抱怨，不如耐心修行，若能成为仙师，也能回报家族"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：好家伙，一群人凑不出半个本地人"}]}
execute as @s if score @s jqtime matches 54 run tellraw @s {"rawtext":[{"text":"[叶飞鹏]：兄弟你看的有些眼熟啊，不知在大离官居何职？"}]}
execute as @s if score @s jqtime matches 57 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：？。。。。。哼！（关你屁事）"}]}
execute as @s if score @s jqtime matches 57 run camera @s fade time 1 3 0.5 color 0 0 0 
execute as @s if score @s jqtime matches 60 run tp @s 3622 11 2034
execute as @s if score @s jqtime matches 63 run tellraw @s {"rawtext":[{"text":"--琉璃岛"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"--在天宝楼的安排下，众人在赵管事那里，领取了身份灵符"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[孙章]: 如今户籍已经到手,契书可以签字了吧？"}]}
execute as @s if score @s jqtime matches 74 run tellraw @s {"rawtext":[{"text":"[苏长玉]: 等我们彻底安定下来后，我就签署最后的契约"}]}
execute as @s if score @s jqtime matches 78 run tellraw @s {"rawtext":[{"text":"[孙章]: 跟你们离界打交道就是麻烦，要不是看在仙师的份上，我们天宝楼，才不会做这亏本生意"}]}
execute as @s if score @s jqtime matches 82 run tellraw @s {"rawtext":[{"text":"[苏长玉]: 不知我等想要修行，该怎么做？"}]}
execute as @s if score @s jqtime matches 86 run tellraw @s {"rawtext":[{"text":"[孙章]: 你们须先祛除一身瘴气，否者是无法修仙的。"}]}
execute as @s if score @s jqtime matches 90 run tellraw @s {"rawtext":[{"text":"[苏长玉]: 不知这仙凡瘴该如何去除？"}]}
execute as @s if score @s jqtime matches 94 run tellraw @s {"rawtext":[{"text":"[孙章]: 去除瘴气，有多种方法，一是那岛上的净体灵池，浸泡一天一夜，便可将体内瘴气尽数除去"}]}
execute as @s if score @s jqtime matches 99 run tellraw @s {"rawtext":[{"text":"[孙章]: 其二就是修行《玄黄清心咒》，日积月累下，可将体内瘴气完全清除，但耗时长久，往往需要五六年"}]}
execute as @s if score @s jqtime matches 102 run tellraw @s {"rawtext":[{"text":"[孙章]: 还有一种方法，则是当实验体，让仙师强行抽取体内瘴气，用于研究"}]}
execute as @s if score @s jqtime matches 106 run tellraw @s {"rawtext":[{"text":"[孙章]: 净体灵池竞争激烈，玄黄清心咒虽然耗时，但是胜在便宜安全，最后一种方法，听说过程极其痛苦，并非常人所能忍受，们好好考虑吧"}]}
execute as @s if score @s jqtime matches 110 run tellraw @s {"rawtext":[{"text":"[苏长玉]: 多谢孙长老解惑"}]}
execute as @s if score @s jqtime matches 113 run tellraw @s {"rawtext":[{"text":"[孙章]: 仙道艰难，就算能去除一身瘴气，之后能顺利引气入体的人，也是少之又少，各位好自为之"}]}
execute as @s if score @s jqtime matches 113 run spawnpoint @s ~~~ 
execute as @s at @s if score @s jqtime matches 115 run playsound random.levelup @s
execute as @s at @s if score @s jqtime matches 115 run scoreboard players set @s zq 0
execute as @s if score @s jqtime matches 115 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 115 run scoreboard players set @s rwa 27
execute as @s if score @s jqtime matches 116 run tag @s add jqa 