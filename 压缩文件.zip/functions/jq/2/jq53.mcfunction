execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"-前几日苏长玉为了尽快祛除体内瘴气，选择了去个仙师当实验体了！"}]}
execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"-你没想到他为了修仙救他那个身患绝症的妹妹，竟然如此果决"}]}
execute as @s if score @s jqtime matches 12 run tellraw @s {"rawtext":[{"text":"-不过现在传来一个令你震惊的消息"}]}
execute as @s if score @s jqtime matches 16 run tellraw @s {"rawtext":[{"text":"[萧恒]：你快去看看吧，苏长玉死了！！！呜呜呜"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：唉，仙道艰难呀！"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：这苏长玉敢闯敢拼，且心智坚定，本以为他能闯出个名堂，没想到就这么倒在了修仙之路的第一步（感到唏嘘）[心里话]"}]}
execute as @s if score @s jqtime matches 28 run tellraw @s {"rawtext":[{"text":"-而在接下来修行《玄黄清心咒》的过程中，你对此的感受是愈发深刻。一般来说，常人修行半个月后，就会有精神变好、思维速度变得更快等明显效果。"}]}
execute as @s if score @s jqtime matches 32 run tellraw @s {"rawtext":[{"text":"-可是一个月过去了，你愣是没有感到任何变化。"}]}
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"-你打算洗白你从大玄国带来的钱财，用来求一个净体名额"}]}
execute as @s at @s if score @s jqtime matches 39 run playsound random.levelup @s
execute as @s if score @s jqtime matches 39 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 39 run scoreboard players set @s rwa 28
execute as @s if score @s jqtime matches 40 run tag @s add jqa