execute as @s if score @s jqtime matches 1 run camera @s fade time 2 5 2 color 0 0 0
execute as @s if score @s jqtime matches 3 run tp @s 3902 -3 1950
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：怎么这次出来在海上？，上一世山脉，还有城镇"}]}
execute as @s if score @s jqtime matches 15 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：罢了，只能走一步看一步。"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：那边貌似有船，去看看"}]}
execute as @s at @s if score @s jqtime matches 23 run playsound random.levelup @s
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 23 run scoreboard players set @s rwa 26