execute as @s if score @s jqtime matches 1 run camera @s set minecraft:free ease 2 linear pos 3663 43 1921 rot 0 220
execute as @s if score @s jqtime matches 1 run tickingarea add 3776 55 1855 3720 32 1886 temp1
execute as @s if score @s jqtime matches 3..8 run playsound mace.heavy_smash_ground @a ~~~ 1 0.2 10
execute as @s if score @s jqtime matches 10 run playsound mace.heavy_smash_ground @a ~~~ 1 0.2 10
execute as @s if score @s jqtime matches 13 run playsound mace.heavy_smash_ground @a ~~~ 1 0.2 10
execute as @s if score @s jqtime matches 16 run playsound mace.heavy_smash_ground @a ~~~ 1 0.2 10
execute as @s if score @s jqtime matches 19 run playsound mace.heavy_smash_ground @a ~~~ 1 0.2 10
execute as @s if score @s jqtime matches 3 run summon minecraft:lightning_bolt 3718 53 1902
execute as @s if score @s jqtime matches 3 run summon minecraft:lightning_bolt 3729 51 1910
execute as @s if score @s jqtime matches 3 run summon minecraft:lightning_bolt 3732 47 1898
execute as @s if score @s jqtime matches 3 run summon minecraft:lightning_bolt 3745 57 1877
execute as @s if score @s jqtime matches 4 run summon minecraft:lightning_bolt 3736 42 1874
execute as @s if score @s jqtime matches 4 run summon minecraft:lightning_bolt 3745 62 1867
execute as @s if score @s jqtime matches 4 run summon minecraft:lightning_bolt 3761 61 1865
execute as @s if score @s jqtime matches 4 run summon minecraft:lightning_bolt 3707 11 1883
execute as @s if score @s jqtime matches 5 run summon minecraft:lightning_bolt 3725 28 1896
execute as @s if score @s jqtime matches 5 run summon minecraft:lightning_bolt 3718 53 1902
execute as @s if score @s jqtime matches 5 run summon minecraft:lightning_bolt 3729 51 1910
execute as @s if score @s jqtime matches 5 run summon minecraft:lightning_bolt 3732 47 1898
execute as @s if score @s jqtime matches 6 run summon minecraft:lightning_bolt 3745 57 1877
execute as @s if score @s jqtime matches 6 run summon minecraft:lightning_bolt 3736 42 1874
execute as @s if score @s jqtime matches 6 run summon minecraft:lightning_bolt 3745 62 1867
execute as @s if score @s jqtime matches 7 run camera @s set minecraft:free ease 1 linear pos ~~1.7~ rot ~~
execute as @s if score @s jqtime matches 8 run camera @s clear
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"-原版你是想出海洗白你的钱财的，但是突然来了风灾"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：这风灾好生恐怖，之前在琉璃岛众人的交谈中，听到过好多次风灾风灾的，我都没有怎么在意。以为最多就是像穿越前见识过的台风、飓风一样，不过是大点的风暴罢了。（心里话）"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：可当风灾真的到来了，这才知道，自己是大错特错！（心里话）"}]}
execute as @s if score @s jqtime matches 24 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：怎么这雷声没了（心里话）"}]}
execute as @s if score @s jqtime matches 27 run tellraw @s {"rawtext":[{"text":"[远处]：护岛大阵已经开启，无需惊慌！躲在家中，不许外出！"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[众凡人]：仙师慈悲！"}]}
execute as @s if score @s jqtime matches 34 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：外界是狂风骤雨，内部则是风平浪静，这就是仙家手段么？（心里话）"}]}
execute as @s if score @s jqtime matches 36 run summon minecraft:lightning_bolt ~~10~
execute as @s if score @s jqtime matches 38 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：怎么感觉有点不对劲？"}]}
execute as @s if score @s jqtime matches 39 run effect @s darkness 40 0 true
execute as @s if score @s jqtime matches 40..50 run camerashake add @s 1 0.7 rotational
execute as @s if score @s jqtime matches 40..50 if score @s hp matches 10.. run scoreboard players set @s sskx 9
execute as @s if score @s jqtime matches 40..50 if score @s hp matches 10.. run scoreboard players operation @s sskx += @s fyfy
execute as @s if score @s jqtime matches 40 run summon minecraft:lightning_bolt ~~10~
execute as @s if score @s jqtime matches 43 run summon minecraft:lightning_bolt ~~10~
execute as @s if score @s jqtime matches 46 run summon minecraft:lightning_bolt ~~10~
execute as @s if score @s jqtime matches 49 run summon minecraft:lightning_bolt ~~10~
execute as @s if score @s jqtime matches 53 run tellraw @s {"rawtext":[{"text":"-过了许久。"}]}
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"[岛员a] 这次风灾规模比以往的都小呀！"}]}
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[岛员b] 可不是嘛，十五年前的那场风灾，威力是这次的数倍，护岛大阵也几乎维持不住琉璃岛的面积，也变得只有原来三分之一大。现在想想真当恐怖QWQ"}]}
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"[岛员c] 叩谢仙师！"}]}
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：风灾，原来这就是风灾么……天地之威，竟然恐怖如斯！"}]}
execute as @s if score @s jqtime matches 70 run tickingarea remove temp1
execute as @s if score @s jqtime matches 71 run tag @s add jqa