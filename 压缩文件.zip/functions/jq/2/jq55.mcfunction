execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"-今天你出海了"}]}
execute as @s if score @s jqtime matches 4 run tellraw @s {"rawtext":[{"text":"-但是明显感到感到船长张浩波针对你。"}]}
execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"-全是因为你说自己天生异瞳，可以看见“运”"}]}
execute as @s if score @s jqtime matches 12 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：我感受到了，往这边走"}]}
execute as @s if score @s jqtime matches 16 run tellraw @s {"rawtext":[{"text":"-虽然张浩波对你并不相信，但他还是往你说的方向走。"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：我感受到了，就是这，赶紧打捞"}]}
execute as @s if score @s jqtime matches 24 run tellraw @s {"rawtext":[{"text":"[船员A]：好重！大家一起用力"}]}
execute as @s if score @s jqtime matches 28 run tellraw @s {"rawtext":[{"text":"[船员B]：真的是金银财宝！！！整整好几箱"}]}
execute as @s if score @s jqtime matches 32 run tellraw @s {"rawtext":[{"text":"[张浩波]：这还打捞这破鱼干嘛，赶紧返航！"}]}
execute as @s if score @s jqtime matches 36 run tellraw @s {"rawtext":[{"text":"-返航中。。。。"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"-返航中。。。。"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"-靠岸了"}]}
execute as @s if score @s jqtime matches 45 run tellraw @s {"rawtext":[{"text":"[张浩波]：赶紧叫天宝楼的赵管事，赶紧！50%的利润哈哈哈！"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[张浩波]：跟咱们天宝楼的大掌柜一样--通灵宝体"}]}
execute as @s if score @s jqtime matches 55 run tellraw @s {"rawtext":[{"text":"-随后，你把你的份换成了灵石"}]}
execute as @s if score @s jqtime matches 56 run scoreboard players add @s lsa 5
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：才这么点吗。。看来我要换个计划了"}]}
execute as @s if score @s jqtime matches 64 run tellraw @s {"rawtext":[{"text":"[张浩波]：这人绝对是通灵宝体（对的赵管事说）"}]}
execute as @s if score @s jqtime matches 68 run tellraw @s {"rawtext":[{"text":"[赵管事]：呵呵，运气好点就说通灵宝体，哪怕捞到了金银财宝也不一定是通灵宝体，多半是运气好罢了"}]}
execute as @s if score @s jqtime matches 72 run tellraw @s {"rawtext":[{"text":"[张浩波]：不，这个我打包票，这几乎直接直行到达捞到的"}]}
execute as @s if score @s jqtime matches 75 run tellraw @s {"rawtext":[{"text":"[赵管事]：除非，下次出海一样可以捞到财宝，不然不相信"}]}
execute as @s at @s if score @s jqtime matches 76 run playsound random.levelup @s
execute as @s if score @s jqtime matches 76 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 76 run scoreboard players set @s rwa 29
execute as @s if score @s jqtime matches 76 run tag @s add jqa 

