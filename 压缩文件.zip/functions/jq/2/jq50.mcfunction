execute as @s if score @s jqtime matches 1 run tellraw @s {"rawtext":[{"text":"[从云海驻守]：真是瞌睡来了，送枕头"}]}
execute as @s if score @s jqtime matches 5 run tellraw @s {"rawtext":[{"text":"[从云海驻守]：老早就看到你了，刚上位一年就有业绩，真乃天助我也"}]}
execute as @s if score @s jqtime matches 9 run tellraw @s {"rawtext":[{"text":"[从云海驻守]：没想到你还想过来，真是有趣"}]}
execute as @s if score @s jqtime matches 13 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：什么？"}]}
execute as @s if score @s jqtime matches 13 run effect @s darkness 10 0 true
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"§4§l还真！！！！"}]}
execute as @s if score @s jqtime matches 15 run tp @s 313 53 198 
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"还真：充能完毕，是否将当前场景虚拟化，回归最初锚点。"}]}
execute as @s if score @s jqtime matches 19 run tellraw @s {"rawtext":[{"text":"【本次模拟结束】(下一世不会清除物品，请放心的肝吧)"}]}
execute as @s if score @s jqtime matches 20 run tellraw @s {"rawtext":[{"text":"【你可以在以下选项中选择一项进行保留：】"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"1.本次模拟中自身持有的一件物品。"}]}
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"2.本次模拟中自身的修行境界。"}]}
execute as @s if score @s jqtime matches 23 run tellraw @s {"rawtext":[{"text":"3.本次模拟中与自身关系密切的一位人员的模拟记忆。此记忆可让该人员继承。"}]}
execute as @s if score @s jqtime matches 24 run tellraw @s {"rawtext":[{"text":"4.放弃以上选择，加快充能进度"}]}
execute as @s if score @s jqtime matches 28 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：修仙世界，恐怖如斯."}]}
execute as @s if score @s jqtime matches 32 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：连一个凡人都不放过"}]}
execute as @s if score @s jqtime matches 36 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：原本终于踏足这修仙界，结果没走出几步就被抓走"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：哼，无妨，下一世这修仙界便是我长生之路的起点，但求长生，百世无悔！"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：选择保留太衍舟"}]}
execute as @s if score @s jqtime matches 44 run camera @s fade time 2 5 2 color 0 0 0
execute as @s if score @s jqtime matches 47 run tp @s 172 59 260
execute as @s if score @s jqtime matches 48 run tag @s add jqa
