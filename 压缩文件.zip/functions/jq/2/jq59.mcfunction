execute as @s if score @s jqtime matches 1 run camera @s fade time 2 50 2 color 0 0 0
execute as @s if score @s jqtime matches 3 run tellraw @s {"rawtext":[{"text":"-你在净体灵池中沐浴，一连八日，震惊主持净体灵池的何正浩，觉得你有大毅力，自讨腰包给你补上这6天"}]}
execute as @s if score @s jqtime matches 8 run tellraw @s {"rawtext":[{"text":"[何正浩]: 恭喜小友！自此桎梏尽去，长生有望！"}]}
execute as @s if score @s jqtime matches 12 run tellraw @s {"rawtext":[{"text":"[何正浩]: 小友真乃大毅力之人，居然在此八日不辍，佩服佩服！"}]}
execute as @s if score @s jqtime matches 16 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 什么？我在里面竟然待了这么久？"}]}
execute as @s if score @s jqtime matches 21 run tellraw @s {"rawtext":[{"text":"[何正浩]: 是啊，小友可是不知道啊，这阵法材料早就要耗尽了。还是我下了血本，又为小友重新添加了一份……"}]}
execute as @s if score @s jqtime matches 25 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：仙师之恩，凡不敢忘。他日必有厚报。"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[何正浩]: 无他，祛除瘴气之后，便是感受天地灵气，引气入体。若是能在体内凝练出第一丝灵气，就代表着进入了炼气期，此时就可以正式被称之为修仙者了。这本《五灵感气法》，乃是前人关于感应灵气的经验总结，你需好好研读。"}]}
execute as @s if score @s jqtime matches 35 run tellraw @s {"rawtext":[{"text":"[何正浩]: 还有这个练气丹，乃是我特地为小友炼制的，服下之后，可以帮助小友突破练气期"}]}
execute as @s if score @s jqtime matches 35 run structure load "2/dy/lq_lqd" ~~~
execute as @s if score @s jqtime matches 35 run structure load "2/五灵感气法" ~~~
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"-出来后，你收到了来自萧恒的信件"}]}
execute as @s if score @s jqtime matches 44 run tellraw @s {"rawtext":[{"text":"萧恒--我这几天天梦到仙师从天而降，把我们尽数斩杀，每日担心受怕，为了能安心入眠，更为了成为修仙者，不用再每日担惊受怕"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"萧恒--于是就开始认真修仙《玄黄清心咒》，没想到几天就除瘴成功，随后更是感到了天地灵气亲昵地在我周围徘徊游走。睡了一觉便引气入体成功了"}]}
execute as @s if score @s jqtime matches 56 run tellraw @s {"rawtext":[{"text":"萧恒--我知道你心向修仙，这么久才祛瘴成功，怕刺激到你，就找到赵管事，把这信交给你"}]}
execute as @s if score @s jqtime matches 59 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]：《那’玄黄清心咒‘一读就昏昏欲睡，实在是提不起兴趣》（你突然回想起这话）"}]}
execute as @s if score @s jqtime matches 64 run tellraw @s {"rawtext":[{"text":"萧恒--弟有今日，全赖兄之庇佑。"}]}
execute as @s if score @s jqtime matches 65 run tellraw @s {"rawtext":[{"text":"萧恒--今闻兄成功祛瘴，想必不日便可突破炼气。"}]}
execute as @s if score @s jqtime matches 66 run tellraw @s {"rawtext":[{"text":"萧恒--弟先行一步，于万仙岛恭候兄之大驾。"}]}
execute as @s if score @s jqtime matches 67 run tellraw @s {"rawtext":[{"text":"萧恒--相见之日，若兄有所托，弟虽万死亦不敢辞"}]}
execute as @s if score @s jqtime matches 68 run tellraw @s {"rawtext":[{"text":"萧恒--恒顿首再拜。"}]}
execute as @s at @s if score @s jqtime matches 70 run playsound random.levelup @s
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"§a§l任务§r§f: §a§l任务§r§f更新，请查询任务！"}]}
execute as @s if score @s jqtime matches 70 run scoreboard players set @s rwa 31
execute as @s if score @s jqtime matches 71 run tag @s add jqa