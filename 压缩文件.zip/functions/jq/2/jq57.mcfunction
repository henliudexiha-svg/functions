execute as @s if score @s jqtime matches 1 run camera @s fade time 2 2 1 color 0 0 0
execute as @s if score @s jqtime matches 3 run tp @s 3720.45 51.00 1854.43 180 0
execute as @s if score @s jqtime matches 3 run structure load "2/赵管事" 3722 51 1853
execute as @s if score @s jqtime matches 4 as @e[name=赵管事] at @s run tp @s ~~~ 176 0
execute as @s if score @s jqtime matches 7 run tellraw @s {"rawtext":[{"text":"[吴行走]: 赵管事，好久不见呀"}]}
execute as @s if score @s jqtime matches 10 run tellraw @s {"rawtext":[{"text":"[赵管事]: 吴行走？上次咱们见面还是三年前了吧。"}]}
execute as @s if score @s jqtime matches 14 run tellraw @s {"rawtext":[{"text":"[吴行走]: 时间真是过的飞快啊。"}]}
execute as @s if score @s jqtime matches 18 run tellraw @s {"rawtext":[{"text":"[吴行走]: 这位是？"}]}
execute as @s if score @s jqtime matches 22 run tellraw @s {"rawtext":[{"text":"[赵管事]: 我们天宝楼聘请的长老。"}]}
execute as @s if score @s jqtime matches 26 run tellraw @s {"rawtext":[{"text":"[吴行走]: 还是看看货吧。恐怕这次之后，我们很难再见面了。"}]}
execute as @s if score @s jqtime matches 30 run tellraw @s {"rawtext":[{"text":"[吴行走]: 若不是已经跟你约好交易的日子，此刻恐怕我已经在回去的路上了。"}]}
execute as @s if score @s jqtime matches 34 run tellraw @s {"rawtext":[{"text":"["},{"selector":"@s"},{"text":"]： 玉璧十六对、珊瑚二十三件、夜明珍珠四十六颗……"}]}
execute as @s if score @s jqtime matches 37 run tellraw @s {"rawtext":[{"text":"[吴行走]: 这是？星海流沙？赵管事，这次好运气啊。居然搜集到了星海流沙这等好物。"}]}
execute as @s if score @s jqtime matches 40 run tellraw @s {"rawtext":[{"text":"-这之后便没有什么贵重的东西了，赵行走对此次天宝楼提供的货物很满意。\n并且因为双方以后很长时间都不能再见的原因，他特地邀请二人做客。\n酒足饭饱之后，赵行走又将二人领到飞舟的仓库中。"}]}
execute as @s if score @s jqtime matches 50 run tellraw @s {"rawtext":[{"text":"[吴行走]:这些都是我在从云海各个岛屿中收来的，有些价值连城，有些则是我也不清楚作用。只是看着稀奇，就顺便买下。二位若有兴趣，可以从中挑几件。"}]}
execute as @s if score @s jqtime matches 53 run tellraw @s {"rawtext":[{"text":"[赵管事]: 那就恭敬不如从命了"}]}
execute as @s if score @s jqtime matches 55 run scoreboard players set @e[name=赵管事] wy 1
execute as @s if score @s jqtime matches 56 as @e[name=赵管事] at @s run tp @s ~~~ 90 0
execute as @s if score @s jqtime matches 60 run tellraw @s {"rawtext":[{"text":"[赵管事]: 这就是回响晶体吗？"}]}
execute as @s if score @s jqtime matches 64 as @e[name=赵管事] at @s run tp @s ~~~ 270 0
execute as @s if score @s jqtime matches 64 run scoreboard players set @e[name=赵管事] wy 2
execute as @s if score @s jqtime matches 70 run tellraw @s {"rawtext":[{"text":"[赵管事]: 这看上去也不错"}]}
execute as @s if score @s jqtime matches ..70 if block ~~-0.5~ minecraft:end_portal run tellraw @s {"rawtext":[{"text":"----等等"}]}
execute as @s if score @s jqtime matches 70.. if block ~~-0.5~ minecraft:end_portal run tag @s add jqa


execute as @s if score @s jqtime matches 80 run scoreboard players set @e[name=赵管事] wy 1
execute as @s if score @s jqtime matches 81 as @e[name=赵管事] at @s run tp @s ~~~ 90 0
execute as @s if score @s jqtime matches 87 run tellraw @s {"rawtext":[{"text":"[赵管事]: 这就是回响晶体吗？"}]}
execute as @s if score @s jqtime matches 90 as @e[name=赵管事] at @s run tp @s ~~~ 270 0
execute as @s if score @s jqtime matches 95 run scoreboard players set @e[name=赵管事] wy 2
execute as @s if score @s jqtime matches 100 run tellraw @s {"rawtext":[{"text":"[赵管事]: 这看上去也不错"}]}