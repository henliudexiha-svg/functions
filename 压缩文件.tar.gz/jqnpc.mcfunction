


execute as @a at @s if entity @e[type=npc,r=3] run tag @s add jqnpc
execute as @a at @s unless entity @e[type=npc,r=3] run tag @s remove jqnpc
execute as @a[tag=jqnpc] run replaceitem entity @s slot.hotbar 8 minecraft:experience_bottle 6 1 {"item_lock": { "mode": "lock_in_slot" } }